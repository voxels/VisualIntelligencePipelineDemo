import Foundation
import Testing
import Api

@Suite("MessagesClient Wire Tests") struct MessagesClientWireTests {
    @Test func getTypedMessage1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "text": "text",
                  "message_type": "text"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = .text(
            .init(
                text: "text"
            )
        )
        let response = try await client.messages.getTypedMessage(
            jobUuid: "job_uuid",
            messageId: "message_id"
        )
        try #require(response == expectedResponse)
    }

    @Test func getTypedMessage2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "message_type": "text",
                  "text": "text"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = .text(
            .init(
                text: "text"
            )
        )
        let response = try await client.messages.getTypedMessage(
            jobUuid: "job_uuid",
            messageId: "message_id"
        )
        try #require(response == expectedResponse)
    }

    @Test func listMessages1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "messages": [
                    {
                      "job_uuid": "job_uuid",
                      "message_type": "message_type",
                      "message_data": {
                        "error_type": "error_type",
                        "error_message": "error_message",
                        "message_type": "error"
                      },
                      "id": "id",
                      "sender_type": "sender_type",
                      "sender_id": "sender_id",
                      "created_at": "2024-01-15T09:30:00Z"
                    }
                  ],
                  "has_more": true,
                  "next_cursor": "2024-01-15T09:30:00Z"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = MessageListResponse(
            messages: [
                MessageRead(
                    jobUuid: "job_uuid",
                    messageType: "message_type",
                    messageData: .error(
                        .init(
                            errorType: "error_type",
                            errorMessage: "error_message"
                        )
                    ),
                    id: "id",
                    senderType: "sender_type",
                    senderId: Optional("sender_id"),
                    createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)
                )
            ],
            hasMore: true,
            nextCursor: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601))
        )
        let response = try await client.messages.listMessages(
            jobUuid: "job_uuid",
            limit: 1,
            cursor: "cursor"
        )
        try #require(response == expectedResponse)
    }

    @Test func listMessages2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "messages": [
                    {
                      "job_uuid": "job_uuid",
                      "message_type": "message_type",
                      "message_data": {
                        "message_type": "error",
                        "error_type": "error_type",
                        "error_message": "error_message",
                        "stage": "stage"
                      },
                      "id": "id",
                      "sender_type": "sender_type",
                      "sender_id": "sender_id",
                      "created_at": "2024-01-15T09:30:00Z"
                    },
                    {
                      "job_uuid": "job_uuid",
                      "message_type": "message_type",
                      "message_data": {
                        "message_type": "error",
                        "error_type": "error_type",
                        "error_message": "error_message",
                        "stage": "stage"
                      },
                      "id": "id",
                      "sender_type": "sender_type",
                      "sender_id": "sender_id",
                      "created_at": "2024-01-15T09:30:00Z"
                    }
                  ],
                  "has_more": true,
                  "next_cursor": "2024-01-15T09:30:00Z"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = MessageListResponse(
            messages: [
                MessageRead(
                    jobUuid: "job_uuid",
                    messageType: "message_type",
                    messageData: .error(
                        .init(
                            errorType: "error_type",
                            errorMessage: "error_message",
                            stage: Optional("stage")
                        )
                    ),
                    id: "id",
                    senderType: "sender_type",
                    senderId: Optional("sender_id"),
                    createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)
                ),
                MessageRead(
                    jobUuid: "job_uuid",
                    messageType: "message_type",
                    messageData: .error(
                        .init(
                            errorType: "error_type",
                            errorMessage: "error_message",
                            stage: Optional("stage")
                        )
                    ),
                    id: "id",
                    senderType: "sender_type",
                    senderId: Optional("sender_id"),
                    createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)
                )
            ],
            hasMore: true,
            nextCursor: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601))
        )
        let response = try await client.messages.listMessages(jobUuid: "job_uuid")
        try #require(response == expectedResponse)
    }

    @Test func createMessage1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "job_uuid": "job_uuid",
                  "message_type": "message_type",
                  "message_data": {
                    "error_type": "error_type",
                    "error_message": "error_message",
                    "stage": "stage",
                    "message_type": "error"
                  },
                  "id": "id",
                  "sender_type": "sender_type",
                  "sender_id": "sender_id",
                  "created_at": "2024-01-15T09:30:00Z"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = MessageRead(
            jobUuid: "job_uuid",
            messageType: "message_type",
            messageData: .error(
                .init(
                    errorType: "error_type",
                    errorMessage: "error_message",
                    stage: Optional("stage")
                )
            ),
            id: "id",
            senderType: "sender_type",
            senderId: Optional("sender_id"),
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)
        )
        let response = try await client.messages.createMessage(request: .init(
            jobUuid: "job_uuid",
            messageType: "message_type",
            messageData: MessageCreateMessageData.error(
                .init(
                    errorType: "error_type",
                    errorMessage: "error_message"
                )
            )
        ))
        try #require(response == expectedResponse)
    }

    @Test func createMessage2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "job_uuid": "job_uuid",
                  "message_type": "message_type",
                  "message_data": {
                    "message_type": "error",
                    "error_type": "error_type",
                    "error_message": "error_message",
                    "stage": "stage"
                  },
                  "id": "id",
                  "sender_type": "sender_type",
                  "sender_id": "sender_id",
                  "created_at": "2024-01-15T09:30:00Z"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = MessageRead(
            jobUuid: "job_uuid",
            messageType: "message_type",
            messageData: .error(
                .init(
                    errorType: "error_type",
                    errorMessage: "error_message",
                    stage: Optional("stage")
                )
            ),
            id: "id",
            senderType: "sender_type",
            senderId: Optional("sender_id"),
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)
        )
        let response = try await client.messages.createMessage(request: .init(
            jobUuid: "job_uuid",
            messageType: "message_type",
            messageData: MessageCreateMessageData.error(
                .init(
                    errorType: "error_type",
                    errorMessage: "error_message"
                )
            )
        ))
        try #require(response == expectedResponse)
    }

    @Test func getConversationParticipants1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.messages.getConversationParticipants(jobUuid: "job_uuid")
        try #require(response == expectedResponse)
    }

    @Test func getConversationParticipants2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.messages.getConversationParticipants(jobUuid: "job_uuid")
        try #require(response == expectedResponse)
    }
}