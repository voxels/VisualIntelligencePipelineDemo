import Foundation
import Testing
import Api

@Suite("InputsClient Wire Tests") struct InputsClientWireTests {
    @Test func listInputs1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                [
                  {
                    "input_type": "tiktok",
                    "source": "source",
                    "input_metadata": {
                      "key": "value"
                    },
                    "id": "id",
                    "created_at": "2024-01-15T09:30:00Z",
                    "items": [
                      {
                        "id": "id",
                        "created_at": "2024-01-15T09:30:00Z"
                      }
                    ]
                  }
                ]
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = [
            InputRead(
                inputType: .tiktok,
                source: "source",
                inputMetadata: Optional([
                    "key": JSONValue.string("value")
                ]),
                id: "id",
                createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                items: Optional([
                    ItemRead(
                        id: "id",
                        createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)
                    )
                ])
            )
        ]
        let response = try await client.inputs.listInputs(
            includeItems: true,
            limit: 1,
            offset: 1,
            inputType: "input_type"
        )
        try #require(response == expectedResponse)
    }

    @Test func listInputs2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                [
                  {
                    "input_type": "tiktok",
                    "source": "source",
                    "input_metadata": {
                      "input_metadata": {
                        "key": "value"
                      }
                    },
                    "id": "id",
                    "created_at": "2024-01-15T09:30:00Z",
                    "items": [
                      {
                        "title": "title",
                        "description": "description",
                        "hashtags": [
                          "hashtags",
                          "hashtags"
                        ],
                        "status": "status",
                        "topic": [
                          {
                            "topic": {
                              "key": "value"
                            }
                          },
                          {
                            "topic": {
                              "key": "value"
                            }
                          }
                        ],
                        "summary": "summary",
                        "key_insights": [
                          "key_insights",
                          "key_insights"
                        ],
                        "intent": "intent",
                        "entity_type": "entity_type",
                        "modality": "modality",
                        "format": "format",
                        "audience_level": "audience_level",
                        "timeliness": {
                          "timeliness": {
                            "key": "value"
                          }
                        },
                        "geography": [
                          "geography",
                          "geography"
                        ],
                        "language": "language",
                        "tone": "tone",
                        "source_type": "source_type",
                        "evidence": {
                          "evidence": {
                            "key": "value"
                          }
                        },
                        "safety": {
                          "safety": {
                            "key": "value"
                          }
                        },
                        "accessibility": {
                          "accessibility": {
                            "key": "value"
                          }
                        },
                        "video_attrs": {
                          "video_attrs": {
                            "key": "value"
                          }
                        },
                        "text_attrs": {
                          "text_attrs": {
                            "key": "value"
                          }
                        },
                        "image_attrs": {
                          "image_attrs": {
                            "key": "value"
                          }
                        },
                        "engagement": {
                          "engagement": {
                            "key": "value"
                          }
                        },
                        "dedupe": {
                          "dedupe": {
                            "key": "value"
                          }
                        },
                        "input_id": "input_id",
                        "transcription": {
                          "transcription": {
                            "key": "value"
                          }
                        },
                        "id": "id",
                        "created_at": "2024-01-15T09:30:00Z",
                        "updated_at": "2024-01-15T09:30:00Z",
                        "reference_id": "reference_id",
                        "user_id": "user_id",
                        "note_id": "note_id",
                        "log_url": "log_url"
                      },
                      {
                        "title": "title",
                        "description": "description",
                        "hashtags": [
                          "hashtags",
                          "hashtags"
                        ],
                        "status": "status",
                        "topic": [
                          {
                            "topic": {
                              "key": "value"
                            }
                          },
                          {
                            "topic": {
                              "key": "value"
                            }
                          }
                        ],
                        "summary": "summary",
                        "key_insights": [
                          "key_insights",
                          "key_insights"
                        ],
                        "intent": "intent",
                        "entity_type": "entity_type",
                        "modality": "modality",
                        "format": "format",
                        "audience_level": "audience_level",
                        "timeliness": {
                          "timeliness": {
                            "key": "value"
                          }
                        },
                        "geography": [
                          "geography",
                          "geography"
                        ],
                        "language": "language",
                        "tone": "tone",
                        "source_type": "source_type",
                        "evidence": {
                          "evidence": {
                            "key": "value"
                          }
                        },
                        "safety": {
                          "safety": {
                            "key": "value"
                          }
                        },
                        "accessibility": {
                          "accessibility": {
                            "key": "value"
                          }
                        },
                        "video_attrs": {
                          "video_attrs": {
                            "key": "value"
                          }
                        },
                        "text_attrs": {
                          "text_attrs": {
                            "key": "value"
                          }
                        },
                        "image_attrs": {
                          "image_attrs": {
                            "key": "value"
                          }
                        },
                        "engagement": {
                          "engagement": {
                            "key": "value"
                          }
                        },
                        "dedupe": {
                          "dedupe": {
                            "key": "value"
                          }
                        },
                        "input_id": "input_id",
                        "transcription": {
                          "transcription": {
                            "key": "value"
                          }
                        },
                        "id": "id",
                        "created_at": "2024-01-15T09:30:00Z",
                        "updated_at": "2024-01-15T09:30:00Z",
                        "reference_id": "reference_id",
                        "user_id": "user_id",
                        "note_id": "note_id",
                        "log_url": "log_url"
                      }
                    ]
                  },
                  {
                    "input_type": "tiktok",
                    "source": "source",
                    "input_metadata": {
                      "input_metadata": {
                        "key": "value"
                      }
                    },
                    "id": "id",
                    "created_at": "2024-01-15T09:30:00Z",
                    "items": [
                      {
                        "title": "title",
                        "description": "description",
                        "hashtags": [
                          "hashtags",
                          "hashtags"
                        ],
                        "status": "status",
                        "topic": [
                          {
                            "topic": {
                              "key": "value"
                            }
                          },
                          {
                            "topic": {
                              "key": "value"
                            }
                          }
                        ],
                        "summary": "summary",
                        "key_insights": [
                          "key_insights",
                          "key_insights"
                        ],
                        "intent": "intent",
                        "entity_type": "entity_type",
                        "modality": "modality",
                        "format": "format",
                        "audience_level": "audience_level",
                        "timeliness": {
                          "timeliness": {
                            "key": "value"
                          }
                        },
                        "geography": [
                          "geography",
                          "geography"
                        ],
                        "language": "language",
                        "tone": "tone",
                        "source_type": "source_type",
                        "evidence": {
                          "evidence": {
                            "key": "value"
                          }
                        },
                        "safety": {
                          "safety": {
                            "key": "value"
                          }
                        },
                        "accessibility": {
                          "accessibility": {
                            "key": "value"
                          }
                        },
                        "video_attrs": {
                          "video_attrs": {
                            "key": "value"
                          }
                        },
                        "text_attrs": {
                          "text_attrs": {
                            "key": "value"
                          }
                        },
                        "image_attrs": {
                          "image_attrs": {
                            "key": "value"
                          }
                        },
                        "engagement": {
                          "engagement": {
                            "key": "value"
                          }
                        },
                        "dedupe": {
                          "dedupe": {
                            "key": "value"
                          }
                        },
                        "input_id": "input_id",
                        "transcription": {
                          "transcription": {
                            "key": "value"
                          }
                        },
                        "id": "id",
                        "created_at": "2024-01-15T09:30:00Z",
                        "updated_at": "2024-01-15T09:30:00Z",
                        "reference_id": "reference_id",
                        "user_id": "user_id",
                        "note_id": "note_id",
                        "log_url": "log_url"
                      },
                      {
                        "title": "title",
                        "description": "description",
                        "hashtags": [
                          "hashtags",
                          "hashtags"
                        ],
                        "status": "status",
                        "topic": [
                          {
                            "topic": {
                              "key": "value"
                            }
                          },
                          {
                            "topic": {
                              "key": "value"
                            }
                          }
                        ],
                        "summary": "summary",
                        "key_insights": [
                          "key_insights",
                          "key_insights"
                        ],
                        "intent": "intent",
                        "entity_type": "entity_type",
                        "modality": "modality",
                        "format": "format",
                        "audience_level": "audience_level",
                        "timeliness": {
                          "timeliness": {
                            "key": "value"
                          }
                        },
                        "geography": [
                          "geography",
                          "geography"
                        ],
                        "language": "language",
                        "tone": "tone",
                        "source_type": "source_type",
                        "evidence": {
                          "evidence": {
                            "key": "value"
                          }
                        },
                        "safety": {
                          "safety": {
                            "key": "value"
                          }
                        },
                        "accessibility": {
                          "accessibility": {
                            "key": "value"
                          }
                        },
                        "video_attrs": {
                          "video_attrs": {
                            "key": "value"
                          }
                        },
                        "text_attrs": {
                          "text_attrs": {
                            "key": "value"
                          }
                        },
                        "image_attrs": {
                          "image_attrs": {
                            "key": "value"
                          }
                        },
                        "engagement": {
                          "engagement": {
                            "key": "value"
                          }
                        },
                        "dedupe": {
                          "dedupe": {
                            "key": "value"
                          }
                        },
                        "input_id": "input_id",
                        "transcription": {
                          "transcription": {
                            "key": "value"
                          }
                        },
                        "id": "id",
                        "created_at": "2024-01-15T09:30:00Z",
                        "updated_at": "2024-01-15T09:30:00Z",
                        "reference_id": "reference_id",
                        "user_id": "user_id",
                        "note_id": "note_id",
                        "log_url": "log_url"
                      }
                    ]
                  }
                ]
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = [
            InputRead(
                inputType: .tiktok,
                source: "source",
                inputMetadata: Optional([
                    "input_metadata": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                id: "id",
                createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                items: Optional([
                    ItemRead(
                        title: Optional("title"),
                        description: Optional("description"),
                        hashtags: Optional([
                            "hashtags",
                            "hashtags"
                        ]),
                        status: Optional("status"),
                        topic: Optional([
                            [
                                "topic": JSONValue.object(
                                    [
                                        "key": JSONValue.string("value")
                                    ]
                                )
                            ],
                            [
                                "topic": JSONValue.object(
                                    [
                                        "key": JSONValue.string("value")
                                    ]
                                )
                            ]
                        ]),
                        summary: Optional("summary"),
                        keyInsights: Optional([
                            "key_insights",
                            "key_insights"
                        ]),
                        intent: Optional("intent"),
                        entityType: Optional("entity_type"),
                        modality: Optional("modality"),
                        format: Optional("format"),
                        audienceLevel: Optional("audience_level"),
                        timeliness: Optional([
                            "timeliness": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        geography: Optional([
                            "geography",
                            "geography"
                        ]),
                        language: Optional("language"),
                        tone: Optional("tone"),
                        sourceType: Optional("source_type"),
                        evidence: Optional([
                            "evidence": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        safety: Optional([
                            "safety": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        accessibility: Optional([
                            "accessibility": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        videoAttrs: Optional([
                            "video_attrs": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        textAttrs: Optional([
                            "text_attrs": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        imageAttrs: Optional([
                            "image_attrs": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        engagement: Optional([
                            "engagement": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        dedupe: Optional([
                            "dedupe": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        inputId: Optional("input_id"),
                        transcription: Optional([
                            "transcription": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        id: "id",
                        createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                        updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
                        referenceId: Optional("reference_id"),
                        userId: Optional("user_id"),
                        noteId: Optional("note_id"),
                        logUrl: Optional("log_url")
                    ),
                    ItemRead(
                        title: Optional("title"),
                        description: Optional("description"),
                        hashtags: Optional([
                            "hashtags",
                            "hashtags"
                        ]),
                        status: Optional("status"),
                        topic: Optional([
                            [
                                "topic": JSONValue.object(
                                    [
                                        "key": JSONValue.string("value")
                                    ]
                                )
                            ],
                            [
                                "topic": JSONValue.object(
                                    [
                                        "key": JSONValue.string("value")
                                    ]
                                )
                            ]
                        ]),
                        summary: Optional("summary"),
                        keyInsights: Optional([
                            "key_insights",
                            "key_insights"
                        ]),
                        intent: Optional("intent"),
                        entityType: Optional("entity_type"),
                        modality: Optional("modality"),
                        format: Optional("format"),
                        audienceLevel: Optional("audience_level"),
                        timeliness: Optional([
                            "timeliness": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        geography: Optional([
                            "geography",
                            "geography"
                        ]),
                        language: Optional("language"),
                        tone: Optional("tone"),
                        sourceType: Optional("source_type"),
                        evidence: Optional([
                            "evidence": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        safety: Optional([
                            "safety": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        accessibility: Optional([
                            "accessibility": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        videoAttrs: Optional([
                            "video_attrs": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        textAttrs: Optional([
                            "text_attrs": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        imageAttrs: Optional([
                            "image_attrs": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        engagement: Optional([
                            "engagement": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        dedupe: Optional([
                            "dedupe": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        inputId: Optional("input_id"),
                        transcription: Optional([
                            "transcription": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        id: "id",
                        createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                        updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
                        referenceId: Optional("reference_id"),
                        userId: Optional("user_id"),
                        noteId: Optional("note_id"),
                        logUrl: Optional("log_url")
                    )
                ])
            ),
            InputRead(
                inputType: .tiktok,
                source: "source",
                inputMetadata: Optional([
                    "input_metadata": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                id: "id",
                createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                items: Optional([
                    ItemRead(
                        title: Optional("title"),
                        description: Optional("description"),
                        hashtags: Optional([
                            "hashtags",
                            "hashtags"
                        ]),
                        status: Optional("status"),
                        topic: Optional([
                            [
                                "topic": JSONValue.object(
                                    [
                                        "key": JSONValue.string("value")
                                    ]
                                )
                            ],
                            [
                                "topic": JSONValue.object(
                                    [
                                        "key": JSONValue.string("value")
                                    ]
                                )
                            ]
                        ]),
                        summary: Optional("summary"),
                        keyInsights: Optional([
                            "key_insights",
                            "key_insights"
                        ]),
                        intent: Optional("intent"),
                        entityType: Optional("entity_type"),
                        modality: Optional("modality"),
                        format: Optional("format"),
                        audienceLevel: Optional("audience_level"),
                        timeliness: Optional([
                            "timeliness": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        geography: Optional([
                            "geography",
                            "geography"
                        ]),
                        language: Optional("language"),
                        tone: Optional("tone"),
                        sourceType: Optional("source_type"),
                        evidence: Optional([
                            "evidence": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        safety: Optional([
                            "safety": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        accessibility: Optional([
                            "accessibility": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        videoAttrs: Optional([
                            "video_attrs": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        textAttrs: Optional([
                            "text_attrs": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        imageAttrs: Optional([
                            "image_attrs": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        engagement: Optional([
                            "engagement": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        dedupe: Optional([
                            "dedupe": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        inputId: Optional("input_id"),
                        transcription: Optional([
                            "transcription": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        id: "id",
                        createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                        updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
                        referenceId: Optional("reference_id"),
                        userId: Optional("user_id"),
                        noteId: Optional("note_id"),
                        logUrl: Optional("log_url")
                    ),
                    ItemRead(
                        title: Optional("title"),
                        description: Optional("description"),
                        hashtags: Optional([
                            "hashtags",
                            "hashtags"
                        ]),
                        status: Optional("status"),
                        topic: Optional([
                            [
                                "topic": JSONValue.object(
                                    [
                                        "key": JSONValue.string("value")
                                    ]
                                )
                            ],
                            [
                                "topic": JSONValue.object(
                                    [
                                        "key": JSONValue.string("value")
                                    ]
                                )
                            ]
                        ]),
                        summary: Optional("summary"),
                        keyInsights: Optional([
                            "key_insights",
                            "key_insights"
                        ]),
                        intent: Optional("intent"),
                        entityType: Optional("entity_type"),
                        modality: Optional("modality"),
                        format: Optional("format"),
                        audienceLevel: Optional("audience_level"),
                        timeliness: Optional([
                            "timeliness": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        geography: Optional([
                            "geography",
                            "geography"
                        ]),
                        language: Optional("language"),
                        tone: Optional("tone"),
                        sourceType: Optional("source_type"),
                        evidence: Optional([
                            "evidence": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        safety: Optional([
                            "safety": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        accessibility: Optional([
                            "accessibility": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        videoAttrs: Optional([
                            "video_attrs": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        textAttrs: Optional([
                            "text_attrs": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        imageAttrs: Optional([
                            "image_attrs": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        engagement: Optional([
                            "engagement": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        dedupe: Optional([
                            "dedupe": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        inputId: Optional("input_id"),
                        transcription: Optional([
                            "transcription": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]),
                        id: "id",
                        createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                        updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
                        referenceId: Optional("reference_id"),
                        userId: Optional("user_id"),
                        noteId: Optional("note_id"),
                        logUrl: Optional("log_url")
                    )
                ])
            )
        ]
        let response = try await client.inputs.listInputs()
        try #require(response == expectedResponse)
    }

    @Test func createInput1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "input_type": "tiktok",
                  "source": "source",
                  "input_metadata": {
                    "key": "value"
                  },
                  "id": "id",
                  "created_at": "2024-01-15T09:30:00Z",
                  "items": [
                    {
                      "title": "title",
                      "description": "description",
                      "hashtags": [
                        "hashtags"
                      ],
                      "status": "status",
                      "topic": [
                        {
                          "key": "value"
                        }
                      ],
                      "summary": "summary",
                      "key_insights": [
                        "key_insights"
                      ],
                      "intent": "intent",
                      "entity_type": "entity_type",
                      "modality": "modality",
                      "format": "format",
                      "audience_level": "audience_level",
                      "timeliness": {
                        "key": "value"
                      },
                      "geography": [
                        "geography"
                      ],
                      "language": "language",
                      "tone": "tone",
                      "source_type": "source_type",
                      "evidence": {
                        "key": "value"
                      },
                      "safety": {
                        "key": "value"
                      },
                      "accessibility": {
                        "key": "value"
                      },
                      "video_attrs": {
                        "key": "value"
                      },
                      "text_attrs": {
                        "key": "value"
                      },
                      "image_attrs": {
                        "key": "value"
                      },
                      "engagement": {
                        "key": "value"
                      },
                      "dedupe": {
                        "key": "value"
                      },
                      "input_id": "input_id",
                      "transcription": {
                        "key": "value"
                      },
                      "id": "id",
                      "created_at": "2024-01-15T09:30:00Z",
                      "updated_at": "2024-01-15T09:30:00Z",
                      "reference_id": "reference_id",
                      "user_id": "user_id",
                      "note_id": "note_id",
                      "log_url": "log_url"
                    }
                  ]
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = InputRead(
            inputType: .tiktok,
            source: "source",
            inputMetadata: Optional([
                "key": JSONValue.string("value")
            ]),
            id: "id",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            items: Optional([
                ItemRead(
                    title: Optional("title"),
                    description: Optional("description"),
                    hashtags: Optional([
                        "hashtags"
                    ]),
                    status: Optional("status"),
                    topic: Optional([
                        [
                            "key": JSONValue.string("value")
                        ]
                    ]),
                    summary: Optional("summary"),
                    keyInsights: Optional([
                        "key_insights"
                    ]),
                    intent: Optional("intent"),
                    entityType: Optional("entity_type"),
                    modality: Optional("modality"),
                    format: Optional("format"),
                    audienceLevel: Optional("audience_level"),
                    timeliness: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    geography: Optional([
                        "geography"
                    ]),
                    language: Optional("language"),
                    tone: Optional("tone"),
                    sourceType: Optional("source_type"),
                    evidence: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    safety: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    accessibility: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    videoAttrs: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    textAttrs: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    imageAttrs: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    engagement: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    dedupe: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    inputId: Optional("input_id"),
                    transcription: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    id: "id",
                    createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                    updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
                    referenceId: Optional("reference_id"),
                    userId: Optional("user_id"),
                    noteId: Optional("note_id"),
                    logUrl: Optional("log_url")
                )
            ])
        )
        let response = try await client.inputs.createInput(request: .init(
            inputType: .tiktok,
            source: "source"
        ))
        try #require(response == expectedResponse)
    }

    @Test func createInput2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "input_type": "tiktok",
                  "source": "source",
                  "input_metadata": {
                    "input_metadata": {
                      "key": "value"
                    }
                  },
                  "id": "id",
                  "created_at": "2024-01-15T09:30:00Z",
                  "items": [
                    {
                      "title": "title",
                      "description": "description",
                      "hashtags": [
                        "hashtags",
                        "hashtags"
                      ],
                      "status": "status",
                      "topic": [
                        {
                          "topic": {
                            "key": "value"
                          }
                        },
                        {
                          "topic": {
                            "key": "value"
                          }
                        }
                      ],
                      "summary": "summary",
                      "key_insights": [
                        "key_insights",
                        "key_insights"
                      ],
                      "intent": "intent",
                      "entity_type": "entity_type",
                      "modality": "modality",
                      "format": "format",
                      "audience_level": "audience_level",
                      "timeliness": {
                        "timeliness": {
                          "key": "value"
                        }
                      },
                      "geography": [
                        "geography",
                        "geography"
                      ],
                      "language": "language",
                      "tone": "tone",
                      "source_type": "source_type",
                      "evidence": {
                        "evidence": {
                          "key": "value"
                        }
                      },
                      "safety": {
                        "safety": {
                          "key": "value"
                        }
                      },
                      "accessibility": {
                        "accessibility": {
                          "key": "value"
                        }
                      },
                      "video_attrs": {
                        "video_attrs": {
                          "key": "value"
                        }
                      },
                      "text_attrs": {
                        "text_attrs": {
                          "key": "value"
                        }
                      },
                      "image_attrs": {
                        "image_attrs": {
                          "key": "value"
                        }
                      },
                      "engagement": {
                        "engagement": {
                          "key": "value"
                        }
                      },
                      "dedupe": {
                        "dedupe": {
                          "key": "value"
                        }
                      },
                      "input_id": "input_id",
                      "transcription": {
                        "transcription": {
                          "key": "value"
                        }
                      },
                      "id": "id",
                      "created_at": "2024-01-15T09:30:00Z",
                      "updated_at": "2024-01-15T09:30:00Z",
                      "reference_id": "reference_id",
                      "user_id": "user_id",
                      "note_id": "note_id",
                      "log_url": "log_url"
                    },
                    {
                      "title": "title",
                      "description": "description",
                      "hashtags": [
                        "hashtags",
                        "hashtags"
                      ],
                      "status": "status",
                      "topic": [
                        {
                          "topic": {
                            "key": "value"
                          }
                        },
                        {
                          "topic": {
                            "key": "value"
                          }
                        }
                      ],
                      "summary": "summary",
                      "key_insights": [
                        "key_insights",
                        "key_insights"
                      ],
                      "intent": "intent",
                      "entity_type": "entity_type",
                      "modality": "modality",
                      "format": "format",
                      "audience_level": "audience_level",
                      "timeliness": {
                        "timeliness": {
                          "key": "value"
                        }
                      },
                      "geography": [
                        "geography",
                        "geography"
                      ],
                      "language": "language",
                      "tone": "tone",
                      "source_type": "source_type",
                      "evidence": {
                        "evidence": {
                          "key": "value"
                        }
                      },
                      "safety": {
                        "safety": {
                          "key": "value"
                        }
                      },
                      "accessibility": {
                        "accessibility": {
                          "key": "value"
                        }
                      },
                      "video_attrs": {
                        "video_attrs": {
                          "key": "value"
                        }
                      },
                      "text_attrs": {
                        "text_attrs": {
                          "key": "value"
                        }
                      },
                      "image_attrs": {
                        "image_attrs": {
                          "key": "value"
                        }
                      },
                      "engagement": {
                        "engagement": {
                          "key": "value"
                        }
                      },
                      "dedupe": {
                        "dedupe": {
                          "key": "value"
                        }
                      },
                      "input_id": "input_id",
                      "transcription": {
                        "transcription": {
                          "key": "value"
                        }
                      },
                      "id": "id",
                      "created_at": "2024-01-15T09:30:00Z",
                      "updated_at": "2024-01-15T09:30:00Z",
                      "reference_id": "reference_id",
                      "user_id": "user_id",
                      "note_id": "note_id",
                      "log_url": "log_url"
                    }
                  ]
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = InputRead(
            inputType: .tiktok,
            source: "source",
            inputMetadata: Optional([
                "input_metadata": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            id: "id",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            items: Optional([
                ItemRead(
                    title: Optional("title"),
                    description: Optional("description"),
                    hashtags: Optional([
                        "hashtags",
                        "hashtags"
                    ]),
                    status: Optional("status"),
                    topic: Optional([
                        [
                            "topic": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ],
                        [
                            "topic": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]
                    ]),
                    summary: Optional("summary"),
                    keyInsights: Optional([
                        "key_insights",
                        "key_insights"
                    ]),
                    intent: Optional("intent"),
                    entityType: Optional("entity_type"),
                    modality: Optional("modality"),
                    format: Optional("format"),
                    audienceLevel: Optional("audience_level"),
                    timeliness: Optional([
                        "timeliness": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    geography: Optional([
                        "geography",
                        "geography"
                    ]),
                    language: Optional("language"),
                    tone: Optional("tone"),
                    sourceType: Optional("source_type"),
                    evidence: Optional([
                        "evidence": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    safety: Optional([
                        "safety": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    accessibility: Optional([
                        "accessibility": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    videoAttrs: Optional([
                        "video_attrs": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    textAttrs: Optional([
                        "text_attrs": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    imageAttrs: Optional([
                        "image_attrs": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    engagement: Optional([
                        "engagement": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    dedupe: Optional([
                        "dedupe": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    inputId: Optional("input_id"),
                    transcription: Optional([
                        "transcription": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    id: "id",
                    createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                    updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
                    referenceId: Optional("reference_id"),
                    userId: Optional("user_id"),
                    noteId: Optional("note_id"),
                    logUrl: Optional("log_url")
                ),
                ItemRead(
                    title: Optional("title"),
                    description: Optional("description"),
                    hashtags: Optional([
                        "hashtags",
                        "hashtags"
                    ]),
                    status: Optional("status"),
                    topic: Optional([
                        [
                            "topic": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ],
                        [
                            "topic": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]
                    ]),
                    summary: Optional("summary"),
                    keyInsights: Optional([
                        "key_insights",
                        "key_insights"
                    ]),
                    intent: Optional("intent"),
                    entityType: Optional("entity_type"),
                    modality: Optional("modality"),
                    format: Optional("format"),
                    audienceLevel: Optional("audience_level"),
                    timeliness: Optional([
                        "timeliness": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    geography: Optional([
                        "geography",
                        "geography"
                    ]),
                    language: Optional("language"),
                    tone: Optional("tone"),
                    sourceType: Optional("source_type"),
                    evidence: Optional([
                        "evidence": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    safety: Optional([
                        "safety": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    accessibility: Optional([
                        "accessibility": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    videoAttrs: Optional([
                        "video_attrs": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    textAttrs: Optional([
                        "text_attrs": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    imageAttrs: Optional([
                        "image_attrs": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    engagement: Optional([
                        "engagement": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    dedupe: Optional([
                        "dedupe": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    inputId: Optional("input_id"),
                    transcription: Optional([
                        "transcription": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    id: "id",
                    createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                    updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
                    referenceId: Optional("reference_id"),
                    userId: Optional("user_id"),
                    noteId: Optional("note_id"),
                    logUrl: Optional("log_url")
                )
            ])
        )
        let response = try await client.inputs.createInput(request: .init(
            inputType: .tiktok,
            source: "source"
        ))
        try #require(response == expectedResponse)
    }

    @Test func getInput1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "input_type": "tiktok",
                  "source": "source",
                  "input_metadata": {
                    "key": "value"
                  },
                  "id": "id",
                  "created_at": "2024-01-15T09:30:00Z",
                  "items": [
                    {
                      "title": "title",
                      "description": "description",
                      "hashtags": [
                        "hashtags"
                      ],
                      "status": "status",
                      "topic": [
                        {
                          "key": "value"
                        }
                      ],
                      "summary": "summary",
                      "key_insights": [
                        "key_insights"
                      ],
                      "intent": "intent",
                      "entity_type": "entity_type",
                      "modality": "modality",
                      "format": "format",
                      "audience_level": "audience_level",
                      "timeliness": {
                        "key": "value"
                      },
                      "geography": [
                        "geography"
                      ],
                      "language": "language",
                      "tone": "tone",
                      "source_type": "source_type",
                      "evidence": {
                        "key": "value"
                      },
                      "safety": {
                        "key": "value"
                      },
                      "accessibility": {
                        "key": "value"
                      },
                      "video_attrs": {
                        "key": "value"
                      },
                      "text_attrs": {
                        "key": "value"
                      },
                      "image_attrs": {
                        "key": "value"
                      },
                      "engagement": {
                        "key": "value"
                      },
                      "dedupe": {
                        "key": "value"
                      },
                      "input_id": "input_id",
                      "transcription": {
                        "key": "value"
                      },
                      "id": "id",
                      "created_at": "2024-01-15T09:30:00Z",
                      "updated_at": "2024-01-15T09:30:00Z",
                      "reference_id": "reference_id",
                      "user_id": "user_id",
                      "note_id": "note_id",
                      "log_url": "log_url"
                    }
                  ]
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = InputRead(
            inputType: .tiktok,
            source: "source",
            inputMetadata: Optional([
                "key": JSONValue.string("value")
            ]),
            id: "id",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            items: Optional([
                ItemRead(
                    title: Optional("title"),
                    description: Optional("description"),
                    hashtags: Optional([
                        "hashtags"
                    ]),
                    status: Optional("status"),
                    topic: Optional([
                        [
                            "key": JSONValue.string("value")
                        ]
                    ]),
                    summary: Optional("summary"),
                    keyInsights: Optional([
                        "key_insights"
                    ]),
                    intent: Optional("intent"),
                    entityType: Optional("entity_type"),
                    modality: Optional("modality"),
                    format: Optional("format"),
                    audienceLevel: Optional("audience_level"),
                    timeliness: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    geography: Optional([
                        "geography"
                    ]),
                    language: Optional("language"),
                    tone: Optional("tone"),
                    sourceType: Optional("source_type"),
                    evidence: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    safety: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    accessibility: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    videoAttrs: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    textAttrs: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    imageAttrs: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    engagement: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    dedupe: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    inputId: Optional("input_id"),
                    transcription: Optional([
                        "key": JSONValue.string("value")
                    ]),
                    id: "id",
                    createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                    updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
                    referenceId: Optional("reference_id"),
                    userId: Optional("user_id"),
                    noteId: Optional("note_id"),
                    logUrl: Optional("log_url")
                )
            ])
        )
        let response = try await client.inputs.getInput(inputId: "input_id")
        try #require(response == expectedResponse)
    }

    @Test func getInput2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "input_type": "tiktok",
                  "source": "source",
                  "input_metadata": {
                    "input_metadata": {
                      "key": "value"
                    }
                  },
                  "id": "id",
                  "created_at": "2024-01-15T09:30:00Z",
                  "items": [
                    {
                      "title": "title",
                      "description": "description",
                      "hashtags": [
                        "hashtags",
                        "hashtags"
                      ],
                      "status": "status",
                      "topic": [
                        {
                          "topic": {
                            "key": "value"
                          }
                        },
                        {
                          "topic": {
                            "key": "value"
                          }
                        }
                      ],
                      "summary": "summary",
                      "key_insights": [
                        "key_insights",
                        "key_insights"
                      ],
                      "intent": "intent",
                      "entity_type": "entity_type",
                      "modality": "modality",
                      "format": "format",
                      "audience_level": "audience_level",
                      "timeliness": {
                        "timeliness": {
                          "key": "value"
                        }
                      },
                      "geography": [
                        "geography",
                        "geography"
                      ],
                      "language": "language",
                      "tone": "tone",
                      "source_type": "source_type",
                      "evidence": {
                        "evidence": {
                          "key": "value"
                        }
                      },
                      "safety": {
                        "safety": {
                          "key": "value"
                        }
                      },
                      "accessibility": {
                        "accessibility": {
                          "key": "value"
                        }
                      },
                      "video_attrs": {
                        "video_attrs": {
                          "key": "value"
                        }
                      },
                      "text_attrs": {
                        "text_attrs": {
                          "key": "value"
                        }
                      },
                      "image_attrs": {
                        "image_attrs": {
                          "key": "value"
                        }
                      },
                      "engagement": {
                        "engagement": {
                          "key": "value"
                        }
                      },
                      "dedupe": {
                        "dedupe": {
                          "key": "value"
                        }
                      },
                      "input_id": "input_id",
                      "transcription": {
                        "transcription": {
                          "key": "value"
                        }
                      },
                      "id": "id",
                      "created_at": "2024-01-15T09:30:00Z",
                      "updated_at": "2024-01-15T09:30:00Z",
                      "reference_id": "reference_id",
                      "user_id": "user_id",
                      "note_id": "note_id",
                      "log_url": "log_url"
                    },
                    {
                      "title": "title",
                      "description": "description",
                      "hashtags": [
                        "hashtags",
                        "hashtags"
                      ],
                      "status": "status",
                      "topic": [
                        {
                          "topic": {
                            "key": "value"
                          }
                        },
                        {
                          "topic": {
                            "key": "value"
                          }
                        }
                      ],
                      "summary": "summary",
                      "key_insights": [
                        "key_insights",
                        "key_insights"
                      ],
                      "intent": "intent",
                      "entity_type": "entity_type",
                      "modality": "modality",
                      "format": "format",
                      "audience_level": "audience_level",
                      "timeliness": {
                        "timeliness": {
                          "key": "value"
                        }
                      },
                      "geography": [
                        "geography",
                        "geography"
                      ],
                      "language": "language",
                      "tone": "tone",
                      "source_type": "source_type",
                      "evidence": {
                        "evidence": {
                          "key": "value"
                        }
                      },
                      "safety": {
                        "safety": {
                          "key": "value"
                        }
                      },
                      "accessibility": {
                        "accessibility": {
                          "key": "value"
                        }
                      },
                      "video_attrs": {
                        "video_attrs": {
                          "key": "value"
                        }
                      },
                      "text_attrs": {
                        "text_attrs": {
                          "key": "value"
                        }
                      },
                      "image_attrs": {
                        "image_attrs": {
                          "key": "value"
                        }
                      },
                      "engagement": {
                        "engagement": {
                          "key": "value"
                        }
                      },
                      "dedupe": {
                        "dedupe": {
                          "key": "value"
                        }
                      },
                      "input_id": "input_id",
                      "transcription": {
                        "transcription": {
                          "key": "value"
                        }
                      },
                      "id": "id",
                      "created_at": "2024-01-15T09:30:00Z",
                      "updated_at": "2024-01-15T09:30:00Z",
                      "reference_id": "reference_id",
                      "user_id": "user_id",
                      "note_id": "note_id",
                      "log_url": "log_url"
                    }
                  ]
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = InputRead(
            inputType: .tiktok,
            source: "source",
            inputMetadata: Optional([
                "input_metadata": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            id: "id",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            items: Optional([
                ItemRead(
                    title: Optional("title"),
                    description: Optional("description"),
                    hashtags: Optional([
                        "hashtags",
                        "hashtags"
                    ]),
                    status: Optional("status"),
                    topic: Optional([
                        [
                            "topic": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ],
                        [
                            "topic": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]
                    ]),
                    summary: Optional("summary"),
                    keyInsights: Optional([
                        "key_insights",
                        "key_insights"
                    ]),
                    intent: Optional("intent"),
                    entityType: Optional("entity_type"),
                    modality: Optional("modality"),
                    format: Optional("format"),
                    audienceLevel: Optional("audience_level"),
                    timeliness: Optional([
                        "timeliness": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    geography: Optional([
                        "geography",
                        "geography"
                    ]),
                    language: Optional("language"),
                    tone: Optional("tone"),
                    sourceType: Optional("source_type"),
                    evidence: Optional([
                        "evidence": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    safety: Optional([
                        "safety": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    accessibility: Optional([
                        "accessibility": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    videoAttrs: Optional([
                        "video_attrs": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    textAttrs: Optional([
                        "text_attrs": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    imageAttrs: Optional([
                        "image_attrs": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    engagement: Optional([
                        "engagement": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    dedupe: Optional([
                        "dedupe": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    inputId: Optional("input_id"),
                    transcription: Optional([
                        "transcription": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    id: "id",
                    createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                    updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
                    referenceId: Optional("reference_id"),
                    userId: Optional("user_id"),
                    noteId: Optional("note_id"),
                    logUrl: Optional("log_url")
                ),
                ItemRead(
                    title: Optional("title"),
                    description: Optional("description"),
                    hashtags: Optional([
                        "hashtags",
                        "hashtags"
                    ]),
                    status: Optional("status"),
                    topic: Optional([
                        [
                            "topic": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ],
                        [
                            "topic": JSONValue.object(
                                [
                                    "key": JSONValue.string("value")
                                ]
                            )
                        ]
                    ]),
                    summary: Optional("summary"),
                    keyInsights: Optional([
                        "key_insights",
                        "key_insights"
                    ]),
                    intent: Optional("intent"),
                    entityType: Optional("entity_type"),
                    modality: Optional("modality"),
                    format: Optional("format"),
                    audienceLevel: Optional("audience_level"),
                    timeliness: Optional([
                        "timeliness": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    geography: Optional([
                        "geography",
                        "geography"
                    ]),
                    language: Optional("language"),
                    tone: Optional("tone"),
                    sourceType: Optional("source_type"),
                    evidence: Optional([
                        "evidence": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    safety: Optional([
                        "safety": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    accessibility: Optional([
                        "accessibility": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    videoAttrs: Optional([
                        "video_attrs": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    textAttrs: Optional([
                        "text_attrs": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    imageAttrs: Optional([
                        "image_attrs": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    engagement: Optional([
                        "engagement": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    dedupe: Optional([
                        "dedupe": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    inputId: Optional("input_id"),
                    transcription: Optional([
                        "transcription": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]),
                    id: "id",
                    createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                    updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
                    referenceId: Optional("reference_id"),
                    userId: Optional("user_id"),
                    noteId: Optional("note_id"),
                    logUrl: Optional("log_url")
                )
            ])
        )
        let response = try await client.inputs.getInput(inputId: "input_id")
        try #require(response == expectedResponse)
    }

    @Test func triggerProcessing1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.inputs.triggerProcessing(
            inputId: "input_id",
            stage: "stage"
        )
        try #require(response == expectedResponse)
    }

    @Test func triggerProcessing2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.inputs.triggerProcessing(
            inputId: "input_id",
            stage: "stage"
        )
        try #require(response == expectedResponse)
    }
}