import Foundation
import Testing
import Api

@Suite("ItemsClient Wire Tests") struct ItemsClientWireTests {
    @Test func listItems1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                [
                  {
                    "title": "title",
                    "description": "description",
                    "hashtags": [
                      "hashtags"
                    ],
                    "status": "status",
                    "topic": [
                      {
                        "key": "value"
                      }
                    ],
                    "summary": "summary",
                    "key_insights": [
                      "key_insights"
                    ],
                    "intent": "intent",
                    "entity_type": "entity_type",
                    "modality": "modality",
                    "format": "format",
                    "audience_level": "audience_level",
                    "timeliness": {
                      "key": "value"
                    },
                    "geography": [
                      "geography"
                    ],
                    "language": "language",
                    "tone": "tone",
                    "source_type": "source_type",
                    "evidence": {
                      "key": "value"
                    },
                    "safety": {
                      "key": "value"
                    },
                    "accessibility": {
                      "key": "value"
                    },
                    "video_attrs": {
                      "key": "value"
                    },
                    "text_attrs": {
                      "key": "value"
                    },
                    "image_attrs": {
                      "key": "value"
                    },
                    "engagement": {
                      "key": "value"
                    },
                    "dedupe": {
                      "key": "value"
                    },
                    "input_id": "input_id",
                    "transcription": {
                      "key": "value"
                    },
                    "id": "id",
                    "created_at": "2024-01-15T09:30:00Z",
                    "updated_at": "2024-01-15T09:30:00Z",
                    "reference_id": "reference_id",
                    "user_id": "user_id",
                    "note_id": "note_id",
                    "log_url": "log_url"
                  }
                ]
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = [
            ItemRead(
                title: Optional("title"),
                description: Optional("description"),
                hashtags: Optional([
                    "hashtags"
                ]),
                status: Optional("status"),
                topic: Optional([
                    [
                        "key": JSONValue.string("value")
                    ]
                ]),
                summary: Optional("summary"),
                keyInsights: Optional([
                    "key_insights"
                ]),
                intent: Optional("intent"),
                entityType: Optional("entity_type"),
                modality: Optional("modality"),
                format: Optional("format"),
                audienceLevel: Optional("audience_level"),
                timeliness: Optional([
                    "key": JSONValue.string("value")
                ]),
                geography: Optional([
                    "geography"
                ]),
                language: Optional("language"),
                tone: Optional("tone"),
                sourceType: Optional("source_type"),
                evidence: Optional([
                    "key": JSONValue.string("value")
                ]),
                safety: Optional([
                    "key": JSONValue.string("value")
                ]),
                accessibility: Optional([
                    "key": JSONValue.string("value")
                ]),
                videoAttrs: Optional([
                    "key": JSONValue.string("value")
                ]),
                textAttrs: Optional([
                    "key": JSONValue.string("value")
                ]),
                imageAttrs: Optional([
                    "key": JSONValue.string("value")
                ]),
                engagement: Optional([
                    "key": JSONValue.string("value")
                ]),
                dedupe: Optional([
                    "key": JSONValue.string("value")
                ]),
                inputId: Optional("input_id"),
                transcription: Optional([
                    "key": JSONValue.string("value")
                ]),
                id: "id",
                createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
                referenceId: Optional("reference_id"),
                userId: Optional("user_id"),
                noteId: Optional("note_id"),
                logUrl: Optional("log_url")
            )
        ]
        let response = try await client.items.listItems(
            limit: 1,
            offset: 1,
            intent: "intent",
            modality: "modality",
            format: "format",
            audienceLevel: "audience_level",
            language: "language",
            sourceType: "source_type"
        )
        try #require(response == expectedResponse)
    }

    @Test func listItems2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                [
                  {
                    "title": "title",
                    "description": "description",
                    "hashtags": [
                      "hashtags",
                      "hashtags"
                    ],
                    "status": "status",
                    "topic": [
                      {
                        "topic": {
                          "key": "value"
                        }
                      },
                      {
                        "topic": {
                          "key": "value"
                        }
                      }
                    ],
                    "summary": "summary",
                    "key_insights": [
                      "key_insights",
                      "key_insights"
                    ],
                    "intent": "intent",
                    "entity_type": "entity_type",
                    "modality": "modality",
                    "format": "format",
                    "audience_level": "audience_level",
                    "timeliness": {
                      "timeliness": {
                        "key": "value"
                      }
                    },
                    "geography": [
                      "geography",
                      "geography"
                    ],
                    "language": "language",
                    "tone": "tone",
                    "source_type": "source_type",
                    "evidence": {
                      "evidence": {
                        "key": "value"
                      }
                    },
                    "safety": {
                      "safety": {
                        "key": "value"
                      }
                    },
                    "accessibility": {
                      "accessibility": {
                        "key": "value"
                      }
                    },
                    "video_attrs": {
                      "video_attrs": {
                        "key": "value"
                      }
                    },
                    "text_attrs": {
                      "text_attrs": {
                        "key": "value"
                      }
                    },
                    "image_attrs": {
                      "image_attrs": {
                        "key": "value"
                      }
                    },
                    "engagement": {
                      "engagement": {
                        "key": "value"
                      }
                    },
                    "dedupe": {
                      "dedupe": {
                        "key": "value"
                      }
                    },
                    "input_id": "input_id",
                    "transcription": {
                      "transcription": {
                        "key": "value"
                      }
                    },
                    "id": "id",
                    "created_at": "2024-01-15T09:30:00Z",
                    "updated_at": "2024-01-15T09:30:00Z",
                    "reference_id": "reference_id",
                    "user_id": "user_id",
                    "note_id": "note_id",
                    "log_url": "log_url"
                  },
                  {
                    "title": "title",
                    "description": "description",
                    "hashtags": [
                      "hashtags",
                      "hashtags"
                    ],
                    "status": "status",
                    "topic": [
                      {
                        "topic": {
                          "key": "value"
                        }
                      },
                      {
                        "topic": {
                          "key": "value"
                        }
                      }
                    ],
                    "summary": "summary",
                    "key_insights": [
                      "key_insights",
                      "key_insights"
                    ],
                    "intent": "intent",
                    "entity_type": "entity_type",
                    "modality": "modality",
                    "format": "format",
                    "audience_level": "audience_level",
                    "timeliness": {
                      "timeliness": {
                        "key": "value"
                      }
                    },
                    "geography": [
                      "geography",
                      "geography"
                    ],
                    "language": "language",
                    "tone": "tone",
                    "source_type": "source_type",
                    "evidence": {
                      "evidence": {
                        "key": "value"
                      }
                    },
                    "safety": {
                      "safety": {
                        "key": "value"
                      }
                    },
                    "accessibility": {
                      "accessibility": {
                        "key": "value"
                      }
                    },
                    "video_attrs": {
                      "video_attrs": {
                        "key": "value"
                      }
                    },
                    "text_attrs": {
                      "text_attrs": {
                        "key": "value"
                      }
                    },
                    "image_attrs": {
                      "image_attrs": {
                        "key": "value"
                      }
                    },
                    "engagement": {
                      "engagement": {
                        "key": "value"
                      }
                    },
                    "dedupe": {
                      "dedupe": {
                        "key": "value"
                      }
                    },
                    "input_id": "input_id",
                    "transcription": {
                      "transcription": {
                        "key": "value"
                      }
                    },
                    "id": "id",
                    "created_at": "2024-01-15T09:30:00Z",
                    "updated_at": "2024-01-15T09:30:00Z",
                    "reference_id": "reference_id",
                    "user_id": "user_id",
                    "note_id": "note_id",
                    "log_url": "log_url"
                  }
                ]
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = [
            ItemRead(
                title: Optional("title"),
                description: Optional("description"),
                hashtags: Optional([
                    "hashtags",
                    "hashtags"
                ]),
                status: Optional("status"),
                topic: Optional([
                    [
                        "topic": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ],
                    [
                        "topic": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]
                ]),
                summary: Optional("summary"),
                keyInsights: Optional([
                    "key_insights",
                    "key_insights"
                ]),
                intent: Optional("intent"),
                entityType: Optional("entity_type"),
                modality: Optional("modality"),
                format: Optional("format"),
                audienceLevel: Optional("audience_level"),
                timeliness: Optional([
                    "timeliness": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                geography: Optional([
                    "geography",
                    "geography"
                ]),
                language: Optional("language"),
                tone: Optional("tone"),
                sourceType: Optional("source_type"),
                evidence: Optional([
                    "evidence": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                safety: Optional([
                    "safety": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                accessibility: Optional([
                    "accessibility": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                videoAttrs: Optional([
                    "video_attrs": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                textAttrs: Optional([
                    "text_attrs": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                imageAttrs: Optional([
                    "image_attrs": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                engagement: Optional([
                    "engagement": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                dedupe: Optional([
                    "dedupe": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                inputId: Optional("input_id"),
                transcription: Optional([
                    "transcription": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                id: "id",
                createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
                referenceId: Optional("reference_id"),
                userId: Optional("user_id"),
                noteId: Optional("note_id"),
                logUrl: Optional("log_url")
            ),
            ItemRead(
                title: Optional("title"),
                description: Optional("description"),
                hashtags: Optional([
                    "hashtags",
                    "hashtags"
                ]),
                status: Optional("status"),
                topic: Optional([
                    [
                        "topic": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ],
                    [
                        "topic": JSONValue.object(
                            [
                                "key": JSONValue.string("value")
                            ]
                        )
                    ]
                ]),
                summary: Optional("summary"),
                keyInsights: Optional([
                    "key_insights",
                    "key_insights"
                ]),
                intent: Optional("intent"),
                entityType: Optional("entity_type"),
                modality: Optional("modality"),
                format: Optional("format"),
                audienceLevel: Optional("audience_level"),
                timeliness: Optional([
                    "timeliness": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                geography: Optional([
                    "geography",
                    "geography"
                ]),
                language: Optional("language"),
                tone: Optional("tone"),
                sourceType: Optional("source_type"),
                evidence: Optional([
                    "evidence": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                safety: Optional([
                    "safety": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                accessibility: Optional([
                    "accessibility": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                videoAttrs: Optional([
                    "video_attrs": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                textAttrs: Optional([
                    "text_attrs": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                imageAttrs: Optional([
                    "image_attrs": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                engagement: Optional([
                    "engagement": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                dedupe: Optional([
                    "dedupe": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                inputId: Optional("input_id"),
                transcription: Optional([
                    "transcription": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                id: "id",
                createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
                referenceId: Optional("reference_id"),
                userId: Optional("user_id"),
                noteId: Optional("note_id"),
                logUrl: Optional("log_url")
            )
        ]
        let response = try await client.items.listItems()
        try #require(response == expectedResponse)
    }

    @Test func createItem1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "title": "title",
                  "description": "description",
                  "hashtags": [
                    "hashtags"
                  ],
                  "status": "status",
                  "topic": [
                    {
                      "key": "value"
                    }
                  ],
                  "summary": "summary",
                  "key_insights": [
                    "key_insights"
                  ],
                  "intent": "intent",
                  "entity_type": "entity_type",
                  "modality": "modality",
                  "format": "format",
                  "audience_level": "audience_level",
                  "timeliness": {
                    "key": "value"
                  },
                  "geography": [
                    "geography"
                  ],
                  "language": "language",
                  "tone": "tone",
                  "source_type": "source_type",
                  "evidence": {
                    "key": "value"
                  },
                  "safety": {
                    "key": "value"
                  },
                  "accessibility": {
                    "key": "value"
                  },
                  "video_attrs": {
                    "key": "value"
                  },
                  "text_attrs": {
                    "key": "value"
                  },
                  "image_attrs": {
                    "key": "value"
                  },
                  "engagement": {
                    "key": "value"
                  },
                  "dedupe": {
                    "key": "value"
                  },
                  "input_id": "input_id",
                  "transcription": {
                    "key": "value"
                  },
                  "id": "id",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z",
                  "reference_id": "reference_id",
                  "user_id": "user_id",
                  "note_id": "note_id",
                  "log_url": "log_url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = ItemRead(
            title: Optional("title"),
            description: Optional("description"),
            hashtags: Optional([
                "hashtags"
            ]),
            status: Optional("status"),
            topic: Optional([
                [
                    "key": JSONValue.string("value")
                ]
            ]),
            summary: Optional("summary"),
            keyInsights: Optional([
                "key_insights"
            ]),
            intent: Optional("intent"),
            entityType: Optional("entity_type"),
            modality: Optional("modality"),
            format: Optional("format"),
            audienceLevel: Optional("audience_level"),
            timeliness: Optional([
                "key": JSONValue.string("value")
            ]),
            geography: Optional([
                "geography"
            ]),
            language: Optional("language"),
            tone: Optional("tone"),
            sourceType: Optional("source_type"),
            evidence: Optional([
                "key": JSONValue.string("value")
            ]),
            safety: Optional([
                "key": JSONValue.string("value")
            ]),
            accessibility: Optional([
                "key": JSONValue.string("value")
            ]),
            videoAttrs: Optional([
                "key": JSONValue.string("value")
            ]),
            textAttrs: Optional([
                "key": JSONValue.string("value")
            ]),
            imageAttrs: Optional([
                "key": JSONValue.string("value")
            ]),
            engagement: Optional([
                "key": JSONValue.string("value")
            ]),
            dedupe: Optional([
                "key": JSONValue.string("value")
            ]),
            inputId: Optional("input_id"),
            transcription: Optional([
                "key": JSONValue.string("value")
            ]),
            id: "id",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
            referenceId: Optional("reference_id"),
            userId: Optional("user_id"),
            noteId: Optional("note_id"),
            logUrl: Optional("log_url")
        )
        let response = try await client.items.createItem(request: .init())
        try #require(response == expectedResponse)
    }

    @Test func createItem2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "title": "title",
                  "description": "description",
                  "hashtags": [
                    "hashtags",
                    "hashtags"
                  ],
                  "status": "status",
                  "topic": [
                    {
                      "topic": {
                        "key": "value"
                      }
                    },
                    {
                      "topic": {
                        "key": "value"
                      }
                    }
                  ],
                  "summary": "summary",
                  "key_insights": [
                    "key_insights",
                    "key_insights"
                  ],
                  "intent": "intent",
                  "entity_type": "entity_type",
                  "modality": "modality",
                  "format": "format",
                  "audience_level": "audience_level",
                  "timeliness": {
                    "timeliness": {
                      "key": "value"
                    }
                  },
                  "geography": [
                    "geography",
                    "geography"
                  ],
                  "language": "language",
                  "tone": "tone",
                  "source_type": "source_type",
                  "evidence": {
                    "evidence": {
                      "key": "value"
                    }
                  },
                  "safety": {
                    "safety": {
                      "key": "value"
                    }
                  },
                  "accessibility": {
                    "accessibility": {
                      "key": "value"
                    }
                  },
                  "video_attrs": {
                    "video_attrs": {
                      "key": "value"
                    }
                  },
                  "text_attrs": {
                    "text_attrs": {
                      "key": "value"
                    }
                  },
                  "image_attrs": {
                    "image_attrs": {
                      "key": "value"
                    }
                  },
                  "engagement": {
                    "engagement": {
                      "key": "value"
                    }
                  },
                  "dedupe": {
                    "dedupe": {
                      "key": "value"
                    }
                  },
                  "input_id": "input_id",
                  "transcription": {
                    "transcription": {
                      "key": "value"
                    }
                  },
                  "id": "id",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z",
                  "reference_id": "reference_id",
                  "user_id": "user_id",
                  "note_id": "note_id",
                  "log_url": "log_url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = ItemRead(
            title: Optional("title"),
            description: Optional("description"),
            hashtags: Optional([
                "hashtags",
                "hashtags"
            ]),
            status: Optional("status"),
            topic: Optional([
                [
                    "topic": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ],
                [
                    "topic": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]
            ]),
            summary: Optional("summary"),
            keyInsights: Optional([
                "key_insights",
                "key_insights"
            ]),
            intent: Optional("intent"),
            entityType: Optional("entity_type"),
            modality: Optional("modality"),
            format: Optional("format"),
            audienceLevel: Optional("audience_level"),
            timeliness: Optional([
                "timeliness": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            geography: Optional([
                "geography",
                "geography"
            ]),
            language: Optional("language"),
            tone: Optional("tone"),
            sourceType: Optional("source_type"),
            evidence: Optional([
                "evidence": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            safety: Optional([
                "safety": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            accessibility: Optional([
                "accessibility": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            videoAttrs: Optional([
                "video_attrs": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            textAttrs: Optional([
                "text_attrs": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            imageAttrs: Optional([
                "image_attrs": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            engagement: Optional([
                "engagement": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            dedupe: Optional([
                "dedupe": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            inputId: Optional("input_id"),
            transcription: Optional([
                "transcription": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            id: "id",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
            referenceId: Optional("reference_id"),
            userId: Optional("user_id"),
            noteId: Optional("note_id"),
            logUrl: Optional("log_url")
        )
        let response = try await client.items.createItem(request: .init())
        try #require(response == expectedResponse)
    }

    @Test func getItem1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "title": "title",
                  "description": "description",
                  "hashtags": [
                    "hashtags"
                  ],
                  "status": "queued",
                  "topic": [
                    {
                      "key": "value"
                    }
                  ],
                  "summary": "summary",
                  "key_insights": [
                    "key_insights"
                  ],
                  "intent": "intent",
                  "entity_type": "entity_type",
                  "modality": "modality",
                  "format": "format",
                  "audience_level": "audience_level",
                  "timeliness": {
                    "key": "value"
                  },
                  "geography": [
                    "geography"
                  ],
                  "language": "language",
                  "tone": "tone",
                  "source_type": "source_type",
                  "evidence": {
                    "key": "value"
                  },
                  "safety": {
                    "key": "value"
                  },
                  "accessibility": {
                    "key": "value"
                  },
                  "video_attrs": {
                    "key": "value"
                  },
                  "text_attrs": {
                    "key": "value"
                  },
                  "image_attrs": {
                    "key": "value"
                  },
                  "engagement": {
                    "key": "value"
                  },
                  "dedupe": {
                    "key": "value"
                  },
                  "input_id": "input_id",
                  "transcription": {
                    "key": "value"
                  },
                  "id": "id",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z",
                  "reference_id": "reference_id",
                  "user_id": "user_id",
                  "note_id": "note_id",
                  "log_url": "log_url",
                  "media": [
                    {
                      "key": "value"
                    }
                  ],
                  "references": [
                    "references"
                  ]
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = ItemReadWithRelations(
            title: Optional("title"),
            description: Optional("description"),
            hashtags: Optional([
                "hashtags"
            ]),
            status: Optional(.queued),
            topic: Optional([
                [
                    "key": JSONValue.string("value")
                ]
            ]),
            summary: Optional("summary"),
            keyInsights: Optional([
                "key_insights"
            ]),
            intent: Optional("intent"),
            entityType: Optional("entity_type"),
            modality: Optional("modality"),
            format: Optional("format"),
            audienceLevel: Optional("audience_level"),
            timeliness: Optional([
                "key": JSONValue.string("value")
            ]),
            geography: Optional([
                "geography"
            ]),
            language: Optional("language"),
            tone: Optional("tone"),
            sourceType: Optional("source_type"),
            evidence: Optional([
                "key": JSONValue.string("value")
            ]),
            safety: Optional([
                "key": JSONValue.string("value")
            ]),
            accessibility: Optional([
                "key": JSONValue.string("value")
            ]),
            videoAttrs: Optional([
                "key": JSONValue.string("value")
            ]),
            textAttrs: Optional([
                "key": JSONValue.string("value")
            ]),
            imageAttrs: Optional([
                "key": JSONValue.string("value")
            ]),
            engagement: Optional([
                "key": JSONValue.string("value")
            ]),
            dedupe: Optional([
                "key": JSONValue.string("value")
            ]),
            inputId: Optional("input_id"),
            transcription: Optional([
                "key": JSONValue.string("value")
            ]),
            id: "id",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
            referenceId: Optional("reference_id"),
            userId: Optional("user_id"),
            noteId: Optional("note_id"),
            logUrl: Optional("log_url"),
            media: Optional([
                JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            references: Optional([
                "references"
            ])
        )
        let response = try await client.items.getItem(
            itemId: "item_id",
            includeMedia: true,
            includeReferences: true
        )
        try #require(response == expectedResponse)
    }

    @Test func getItem2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "title": "title",
                  "description": "description",
                  "hashtags": [
                    "hashtags",
                    "hashtags"
                  ],
                  "status": "queued",
                  "topic": [
                    {
                      "topic": {
                        "key": "value"
                      }
                    },
                    {
                      "topic": {
                        "key": "value"
                      }
                    }
                  ],
                  "summary": "summary",
                  "key_insights": [
                    "key_insights",
                    "key_insights"
                  ],
                  "intent": "intent",
                  "entity_type": "entity_type",
                  "modality": "modality",
                  "format": "format",
                  "audience_level": "audience_level",
                  "timeliness": {
                    "timeliness": {
                      "key": "value"
                    }
                  },
                  "geography": [
                    "geography",
                    "geography"
                  ],
                  "language": "language",
                  "tone": "tone",
                  "source_type": "source_type",
                  "evidence": {
                    "evidence": {
                      "key": "value"
                    }
                  },
                  "safety": {
                    "safety": {
                      "key": "value"
                    }
                  },
                  "accessibility": {
                    "accessibility": {
                      "key": "value"
                    }
                  },
                  "video_attrs": {
                    "video_attrs": {
                      "key": "value"
                    }
                  },
                  "text_attrs": {
                    "text_attrs": {
                      "key": "value"
                    }
                  },
                  "image_attrs": {
                    "image_attrs": {
                      "key": "value"
                    }
                  },
                  "engagement": {
                    "engagement": {
                      "key": "value"
                    }
                  },
                  "dedupe": {
                    "dedupe": {
                      "key": "value"
                    }
                  },
                  "input_id": "input_id",
                  "transcription": {
                    "transcription": {
                      "key": "value"
                    }
                  },
                  "id": "id",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z",
                  "reference_id": "reference_id",
                  "user_id": "user_id",
                  "note_id": "note_id",
                  "log_url": "log_url",
                  "media": [
                    {
                      "key": "value"
                    },
                    {
                      "key": "value"
                    }
                  ],
                  "references": [
                    "references",
                    "references"
                  ]
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = ItemReadWithRelations(
            title: Optional("title"),
            description: Optional("description"),
            hashtags: Optional([
                "hashtags",
                "hashtags"
            ]),
            status: Optional(.queued),
            topic: Optional([
                [
                    "topic": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ],
                [
                    "topic": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]
            ]),
            summary: Optional("summary"),
            keyInsights: Optional([
                "key_insights",
                "key_insights"
            ]),
            intent: Optional("intent"),
            entityType: Optional("entity_type"),
            modality: Optional("modality"),
            format: Optional("format"),
            audienceLevel: Optional("audience_level"),
            timeliness: Optional([
                "timeliness": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            geography: Optional([
                "geography",
                "geography"
            ]),
            language: Optional("language"),
            tone: Optional("tone"),
            sourceType: Optional("source_type"),
            evidence: Optional([
                "evidence": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            safety: Optional([
                "safety": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            accessibility: Optional([
                "accessibility": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            videoAttrs: Optional([
                "video_attrs": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            textAttrs: Optional([
                "text_attrs": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            imageAttrs: Optional([
                "image_attrs": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            engagement: Optional([
                "engagement": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            dedupe: Optional([
                "dedupe": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            inputId: Optional("input_id"),
            transcription: Optional([
                "transcription": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            id: "id",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
            referenceId: Optional("reference_id"),
            userId: Optional("user_id"),
            noteId: Optional("note_id"),
            logUrl: Optional("log_url"),
            media: Optional([
                JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                ),
                JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            references: Optional([
                "references",
                "references"
            ])
        )
        let response = try await client.items.getItem(itemId: "item_id")
        try #require(response == expectedResponse)
    }

    @Test func updateItem1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "title": "title",
                  "description": "description",
                  "hashtags": [
                    "hashtags"
                  ],
                  "status": "status",
                  "topic": [
                    {
                      "key": "value"
                    }
                  ],
                  "summary": "summary",
                  "key_insights": [
                    "key_insights"
                  ],
                  "intent": "intent",
                  "entity_type": "entity_type",
                  "modality": "modality",
                  "format": "format",
                  "audience_level": "audience_level",
                  "timeliness": {
                    "key": "value"
                  },
                  "geography": [
                    "geography"
                  ],
                  "language": "language",
                  "tone": "tone",
                  "source_type": "source_type",
                  "evidence": {
                    "key": "value"
                  },
                  "safety": {
                    "key": "value"
                  },
                  "accessibility": {
                    "key": "value"
                  },
                  "video_attrs": {
                    "key": "value"
                  },
                  "text_attrs": {
                    "key": "value"
                  },
                  "image_attrs": {
                    "key": "value"
                  },
                  "engagement": {
                    "key": "value"
                  },
                  "dedupe": {
                    "key": "value"
                  },
                  "input_id": "input_id",
                  "transcription": {
                    "key": "value"
                  },
                  "id": "id",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z",
                  "reference_id": "reference_id",
                  "user_id": "user_id",
                  "note_id": "note_id",
                  "log_url": "log_url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = ItemRead(
            title: Optional("title"),
            description: Optional("description"),
            hashtags: Optional([
                "hashtags"
            ]),
            status: Optional("status"),
            topic: Optional([
                [
                    "key": JSONValue.string("value")
                ]
            ]),
            summary: Optional("summary"),
            keyInsights: Optional([
                "key_insights"
            ]),
            intent: Optional("intent"),
            entityType: Optional("entity_type"),
            modality: Optional("modality"),
            format: Optional("format"),
            audienceLevel: Optional("audience_level"),
            timeliness: Optional([
                "key": JSONValue.string("value")
            ]),
            geography: Optional([
                "geography"
            ]),
            language: Optional("language"),
            tone: Optional("tone"),
            sourceType: Optional("source_type"),
            evidence: Optional([
                "key": JSONValue.string("value")
            ]),
            safety: Optional([
                "key": JSONValue.string("value")
            ]),
            accessibility: Optional([
                "key": JSONValue.string("value")
            ]),
            videoAttrs: Optional([
                "key": JSONValue.string("value")
            ]),
            textAttrs: Optional([
                "key": JSONValue.string("value")
            ]),
            imageAttrs: Optional([
                "key": JSONValue.string("value")
            ]),
            engagement: Optional([
                "key": JSONValue.string("value")
            ]),
            dedupe: Optional([
                "key": JSONValue.string("value")
            ]),
            inputId: Optional("input_id"),
            transcription: Optional([
                "key": JSONValue.string("value")
            ]),
            id: "id",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
            referenceId: Optional("reference_id"),
            userId: Optional("user_id"),
            noteId: Optional("note_id"),
            logUrl: Optional("log_url")
        )
        let response = try await client.items.updateItem(
            itemId: "item_id",
            request: .init(body: [
                "key": .string("value")
            ])
        )
        try #require(response == expectedResponse)
    }

    @Test func updateItem2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "title": "title",
                  "description": "description",
                  "hashtags": [
                    "hashtags",
                    "hashtags"
                  ],
                  "status": "status",
                  "topic": [
                    {
                      "topic": {
                        "key": "value"
                      }
                    },
                    {
                      "topic": {
                        "key": "value"
                      }
                    }
                  ],
                  "summary": "summary",
                  "key_insights": [
                    "key_insights",
                    "key_insights"
                  ],
                  "intent": "intent",
                  "entity_type": "entity_type",
                  "modality": "modality",
                  "format": "format",
                  "audience_level": "audience_level",
                  "timeliness": {
                    "timeliness": {
                      "key": "value"
                    }
                  },
                  "geography": [
                    "geography",
                    "geography"
                  ],
                  "language": "language",
                  "tone": "tone",
                  "source_type": "source_type",
                  "evidence": {
                    "evidence": {
                      "key": "value"
                    }
                  },
                  "safety": {
                    "safety": {
                      "key": "value"
                    }
                  },
                  "accessibility": {
                    "accessibility": {
                      "key": "value"
                    }
                  },
                  "video_attrs": {
                    "video_attrs": {
                      "key": "value"
                    }
                  },
                  "text_attrs": {
                    "text_attrs": {
                      "key": "value"
                    }
                  },
                  "image_attrs": {
                    "image_attrs": {
                      "key": "value"
                    }
                  },
                  "engagement": {
                    "engagement": {
                      "key": "value"
                    }
                  },
                  "dedupe": {
                    "dedupe": {
                      "key": "value"
                    }
                  },
                  "input_id": "input_id",
                  "transcription": {
                    "transcription": {
                      "key": "value"
                    }
                  },
                  "id": "id",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z",
                  "reference_id": "reference_id",
                  "user_id": "user_id",
                  "note_id": "note_id",
                  "log_url": "log_url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = ItemRead(
            title: Optional("title"),
            description: Optional("description"),
            hashtags: Optional([
                "hashtags",
                "hashtags"
            ]),
            status: Optional("status"),
            topic: Optional([
                [
                    "topic": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ],
                [
                    "topic": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]
            ]),
            summary: Optional("summary"),
            keyInsights: Optional([
                "key_insights",
                "key_insights"
            ]),
            intent: Optional("intent"),
            entityType: Optional("entity_type"),
            modality: Optional("modality"),
            format: Optional("format"),
            audienceLevel: Optional("audience_level"),
            timeliness: Optional([
                "timeliness": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            geography: Optional([
                "geography",
                "geography"
            ]),
            language: Optional("language"),
            tone: Optional("tone"),
            sourceType: Optional("source_type"),
            evidence: Optional([
                "evidence": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            safety: Optional([
                "safety": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            accessibility: Optional([
                "accessibility": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            videoAttrs: Optional([
                "video_attrs": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            textAttrs: Optional([
                "text_attrs": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            imageAttrs: Optional([
                "image_attrs": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            engagement: Optional([
                "engagement": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            dedupe: Optional([
                "dedupe": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            inputId: Optional("input_id"),
            transcription: Optional([
                "transcription": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            id: "id",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
            referenceId: Optional("reference_id"),
            userId: Optional("user_id"),
            noteId: Optional("note_id"),
            logUrl: Optional("log_url")
        )
        let response = try await client.items.updateItem(
            itemId: "item_id",
            request: .init(body: [
                "string": .object([
                    "key": .string("value")
                ])
            ])
        )
        try #require(response == expectedResponse)
    }

    @Test func linkItemReference1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.items.linkItemReference(
            itemId: "item_id",
            referenceId: "reference_id"
        )
        try #require(response == expectedResponse)
    }

    @Test func linkItemReference2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.items.linkItemReference(
            itemId: "item_id",
            referenceId: "reference_id"
        )
        try #require(response == expectedResponse)
    }

    @Test func processItem1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.items.processItem(
            itemId: 1,
            tiktokUrl: "tiktok_url"
        )
        try #require(response == expectedResponse)
    }

    @Test func processItem2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.items.processItem(
            itemId: 1,
            tiktokUrl: "tiktok_url"
        )
        try #require(response == expectedResponse)
    }

    @Test func getProcessStatus1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.items.getProcessStatus(
            itemId: 1,
            runId: "run_id"
        )
        try #require(response == expectedResponse)
    }

    @Test func getProcessStatus2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.items.getProcessStatus(
            itemId: 1,
            runId: "run_id"
        )
        try #require(response == expectedResponse)
    }
}