import Foundation
import Testing
import Api

@Suite("ReferencesClient Wire Tests") struct ReferencesClientWireTests {
    @Test func listReferences1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                [
                  {
                    "entity_type": "entity_type",
                    "name": "name",
                    "reference_metadata": {
                      "key": "value"
                    },
                    "id": "id",
                    "user_id": "user_id",
                    "status": "status",
                    "created_at": "2024-01-15T09:30:00Z",
                    "updated_at": "2024-01-15T09:30:00Z"
                  }
                ]
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = [
            ReferenceRead(
                entityType: "entity_type",
                name: "name",
                referenceMetadata: Optional([
                    "key": JSONValue.string("value")
                ]),
                id: "id",
                userId: Optional("user_id"),
                status: "status",
                createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601))
            )
        ]
        let response = try await client.references.listReferences(
            limit: 1,
            offset: 1,
            status: "status",
            entityType: "entity_type"
        )
        try #require(response == expectedResponse)
    }

    @Test func listReferences2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                [
                  {
                    "entity_type": "entity_type",
                    "name": "name",
                    "reference_metadata": {
                      "reference_metadata": {
                        "key": "value"
                      }
                    },
                    "id": "id",
                    "user_id": "user_id",
                    "status": "status",
                    "created_at": "2024-01-15T09:30:00Z",
                    "updated_at": "2024-01-15T09:30:00Z"
                  },
                  {
                    "entity_type": "entity_type",
                    "name": "name",
                    "reference_metadata": {
                      "reference_metadata": {
                        "key": "value"
                      }
                    },
                    "id": "id",
                    "user_id": "user_id",
                    "status": "status",
                    "created_at": "2024-01-15T09:30:00Z",
                    "updated_at": "2024-01-15T09:30:00Z"
                  }
                ]
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = [
            ReferenceRead(
                entityType: "entity_type",
                name: "name",
                referenceMetadata: Optional([
                    "reference_metadata": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                id: "id",
                userId: Optional("user_id"),
                status: "status",
                createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601))
            ),
            ReferenceRead(
                entityType: "entity_type",
                name: "name",
                referenceMetadata: Optional([
                    "reference_metadata": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                id: "id",
                userId: Optional("user_id"),
                status: "status",
                createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601))
            )
        ]
        let response = try await client.references.listReferences()
        try #require(response == expectedResponse)
    }

    @Test func createReference1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "entity_type": "entity_type",
                  "name": "name",
                  "reference_metadata": {
                    "key": "value"
                  },
                  "id": "id",
                  "user_id": "user_id",
                  "status": "status",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = ReferenceRead(
            entityType: "entity_type",
            name: "name",
            referenceMetadata: Optional([
                "key": JSONValue.string("value")
            ]),
            id: "id",
            userId: Optional("user_id"),
            status: "status",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601))
        )
        let response = try await client.references.createReference(request: .init(
            entityType: "entity_type",
            name: "name"
        ))
        try #require(response == expectedResponse)
    }

    @Test func createReference2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "entity_type": "entity_type",
                  "name": "name",
                  "reference_metadata": {
                    "reference_metadata": {
                      "key": "value"
                    }
                  },
                  "id": "id",
                  "user_id": "user_id",
                  "status": "status",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = ReferenceRead(
            entityType: "entity_type",
            name: "name",
            referenceMetadata: Optional([
                "reference_metadata": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            id: "id",
            userId: Optional("user_id"),
            status: "status",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601))
        )
        let response = try await client.references.createReference(request: .init(
            entityType: "entity_type",
            name: "name"
        ))
        try #require(response == expectedResponse)
    }

    @Test func getReference1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "entity_type": "entity_type",
                  "name": "name",
                  "reference_metadata": {
                    "key": "value"
                  },
                  "id": "id",
                  "user_id": "user_id",
                  "status": "status",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = ReferenceRead(
            entityType: "entity_type",
            name: "name",
            referenceMetadata: Optional([
                "key": JSONValue.string("value")
            ]),
            id: "id",
            userId: Optional("user_id"),
            status: "status",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601))
        )
        let response = try await client.references.getReference(
            referenceId: "reference_id",
            includeCreators: true
        )
        try #require(response == expectedResponse)
    }

    @Test func getReference2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "entity_type": "entity_type",
                  "name": "name",
                  "reference_metadata": {
                    "reference_metadata": {
                      "key": "value"
                    }
                  },
                  "id": "id",
                  "user_id": "user_id",
                  "status": "status",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = ReferenceRead(
            entityType: "entity_type",
            name: "name",
            referenceMetadata: Optional([
                "reference_metadata": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            id: "id",
            userId: Optional("user_id"),
            status: "status",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601))
        )
        let response = try await client.references.getReference(referenceId: "reference_id")
        try #require(response == expectedResponse)
    }

    @Test func updateReference1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.references.updateReference(
            referenceId: "reference_id",
            request: [
                "key": .string("value")
            ]
        )
        try #require(response == expectedResponse)
    }

    @Test func updateReference2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.references.updateReference(
            referenceId: "reference_id",
            request: [
                "string": .object([
                    "key": .string("value")
                ])
            ]
        )
        try #require(response == expectedResponse)
    }
}