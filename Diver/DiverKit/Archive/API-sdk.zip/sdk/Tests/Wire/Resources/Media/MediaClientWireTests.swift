import Foundation
import Testing
import Api

@Suite("MediaClient Wire Tests") struct MediaClientWireTests {
    @Test func listMedia1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                [
                  {
                    "filename": "filename",
                    "original_filename": "original_filename",
                    "s3_key": "s3_key",
                    "file_size": 1,
                    "media_type": "image",
                    "mime_type": "mime_type",
                    "width": 1,
                    "height": 1,
                    "duration": 1.1,
                    "aspect_ratio": 1.1,
                    "title": "title",
                    "description": "description",
                    "alt_text": "alt_text",
                    "tags": [
                      "tags"
                    ],
                    "transcription": "transcription",
                    "extracted_text": "extracted_text",
                    "detected_objects": [
                      "detected_objects"
                    ],
                    "colors": [
                      "colors"
                    ],
                    "mood": "mood",
                    "color_palette": {
                      "key": 1.1
                    },
                    "color_distribution": {
                      "key": "value"
                    },
                    "color_temperature": "color_temperature",
                    "color_harmony": "color_harmony",
                    "dominant_hue": "dominant_hue",
                    "color_vibrancy": "color_vibrancy",
                    "color_scheme": "color_scheme",
                    "style": "style",
                    "composition": "composition",
                    "lighting": "lighting",
                    "setting": "setting",
                    "people_count": 1,
                    "faces_detected": [
                      "faces_detected"
                    ],
                    "themes": [
                      "themes"
                    ],
                    "concepts": [
                      "concepts"
                    ],
                    "activities": [
                      "activities"
                    ],
                    "brands_detected": [
                      "brands_detected"
                    ],
                    "blur_level": "blur_level",
                    "saturation": "saturation",
                    "contrast": "contrast",
                    "brightness": "brightness",
                    "texture": [
                      "texture"
                    ],
                    "quality_score": 1.1,
                    "view_count": 1,
                    "download_count": 1,
                    "source_url": "source_url",
                    "source_platform": "source_platform",
                    "sequence_order": 1,
                    "analysis_result": {
                      "key": "value"
                    },
                    "thumbnails": [
                      "thumbnails"
                    ],
                    "id": "id",
                    "item_id": "item_id",
                    "created_at": "2024-01-15T09:30:00Z",
                    "updated_at": "2024-01-15T09:30:00Z",
                    "url": "url"
                  }
                ]
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = [
            MediaRead(
                filename: "filename",
                originalFilename: Optional("original_filename"),
                s3Key: "s3_key",
                fileSize: Optional(1),
                mediaType: .image,
                mimeType: Optional("mime_type"),
                width: Optional(1),
                height: Optional(1),
                duration: Optional(1.1),
                aspectRatio: Optional(1.1),
                title: Optional("title"),
                description: Optional("description"),
                altText: Optional("alt_text"),
                tags: Optional([
                    "tags"
                ]),
                transcription: Optional("transcription"),
                extractedText: Optional("extracted_text"),
                detectedObjects: Optional([
                    "detected_objects"
                ]),
                colors: Optional([
                    "colors"
                ]),
                mood: Optional("mood"),
                colorPalette: Optional([
                    "key": Optional(1.1)
                ]),
                colorDistribution: Optional([
                    "key": JSONValue.string("value")
                ]),
                colorTemperature: Optional("color_temperature"),
                colorHarmony: Optional("color_harmony"),
                dominantHue: Optional("dominant_hue"),
                colorVibrancy: Optional("color_vibrancy"),
                colorScheme: Optional("color_scheme"),
                style: Optional("style"),
                composition: Optional("composition"),
                lighting: Optional("lighting"),
                setting: Optional("setting"),
                peopleCount: Optional(1),
                facesDetected: Optional([
                    "faces_detected"
                ]),
                themes: Optional([
                    "themes"
                ]),
                concepts: Optional([
                    "concepts"
                ]),
                activities: Optional([
                    "activities"
                ]),
                brandsDetected: Optional([
                    "brands_detected"
                ]),
                blurLevel: Optional("blur_level"),
                saturation: Optional("saturation"),
                contrast: Optional("contrast"),
                brightness: Optional("brightness"),
                texture: Optional([
                    "texture"
                ]),
                qualityScore: Optional(1.1),
                viewCount: Optional(1),
                downloadCount: Optional(1),
                sourceUrl: Optional("source_url"),
                sourcePlatform: Optional("source_platform"),
                sequenceOrder: Optional(1),
                analysisResult: Optional([
                    "key": JSONValue.string("value")
                ]),
                thumbnails: Optional([
                    "thumbnails"
                ]),
                id: "id",
                itemId: "item_id",
                createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
                url: Optional("url")
            )
        ]
        let response = try await client.media.listMedia(
            itemId: "item_id",
            limit: 1,
            offset: 1
        )
        try #require(response == expectedResponse)
    }

    @Test func listMedia2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                [
                  {
                    "filename": "filename",
                    "original_filename": "original_filename",
                    "s3_key": "s3_key",
                    "file_size": 1,
                    "media_type": "image",
                    "mime_type": "mime_type",
                    "width": 1,
                    "height": 1,
                    "duration": 1.1,
                    "aspect_ratio": 1.1,
                    "title": "title",
                    "description": "description",
                    "alt_text": "alt_text",
                    "tags": [
                      "tags",
                      "tags"
                    ],
                    "transcription": "transcription",
                    "extracted_text": "extracted_text",
                    "detected_objects": [
                      "detected_objects",
                      "detected_objects"
                    ],
                    "colors": [
                      "colors",
                      "colors"
                    ],
                    "mood": "mood",
                    "color_palette": {
                      "color_palette": 1.1
                    },
                    "color_distribution": {
                      "color_distribution": {
                        "key": "value"
                      }
                    },
                    "color_temperature": "color_temperature",
                    "color_harmony": "color_harmony",
                    "dominant_hue": "dominant_hue",
                    "color_vibrancy": "color_vibrancy",
                    "color_scheme": "color_scheme",
                    "style": "style",
                    "composition": "composition",
                    "lighting": "lighting",
                    "setting": "setting",
                    "people_count": 1,
                    "faces_detected": [
                      "faces_detected",
                      "faces_detected"
                    ],
                    "themes": [
                      "themes",
                      "themes"
                    ],
                    "concepts": [
                      "concepts",
                      "concepts"
                    ],
                    "activities": [
                      "activities",
                      "activities"
                    ],
                    "brands_detected": [
                      "brands_detected",
                      "brands_detected"
                    ],
                    "blur_level": "blur_level",
                    "saturation": "saturation",
                    "contrast": "contrast",
                    "brightness": "brightness",
                    "texture": [
                      "texture",
                      "texture"
                    ],
                    "quality_score": 1.1,
                    "view_count": 1,
                    "download_count": 1,
                    "source_url": "source_url",
                    "source_platform": "source_platform",
                    "sequence_order": 1,
                    "analysis_result": {
                      "analysis_result": {
                        "key": "value"
                      }
                    },
                    "thumbnails": [
                      "thumbnails",
                      "thumbnails"
                    ],
                    "id": "id",
                    "item_id": "item_id",
                    "created_at": "2024-01-15T09:30:00Z",
                    "updated_at": "2024-01-15T09:30:00Z",
                    "url": "url"
                  },
                  {
                    "filename": "filename",
                    "original_filename": "original_filename",
                    "s3_key": "s3_key",
                    "file_size": 1,
                    "media_type": "image",
                    "mime_type": "mime_type",
                    "width": 1,
                    "height": 1,
                    "duration": 1.1,
                    "aspect_ratio": 1.1,
                    "title": "title",
                    "description": "description",
                    "alt_text": "alt_text",
                    "tags": [
                      "tags",
                      "tags"
                    ],
                    "transcription": "transcription",
                    "extracted_text": "extracted_text",
                    "detected_objects": [
                      "detected_objects",
                      "detected_objects"
                    ],
                    "colors": [
                      "colors",
                      "colors"
                    ],
                    "mood": "mood",
                    "color_palette": {
                      "color_palette": 1.1
                    },
                    "color_distribution": {
                      "color_distribution": {
                        "key": "value"
                      }
                    },
                    "color_temperature": "color_temperature",
                    "color_harmony": "color_harmony",
                    "dominant_hue": "dominant_hue",
                    "color_vibrancy": "color_vibrancy",
                    "color_scheme": "color_scheme",
                    "style": "style",
                    "composition": "composition",
                    "lighting": "lighting",
                    "setting": "setting",
                    "people_count": 1,
                    "faces_detected": [
                      "faces_detected",
                      "faces_detected"
                    ],
                    "themes": [
                      "themes",
                      "themes"
                    ],
                    "concepts": [
                      "concepts",
                      "concepts"
                    ],
                    "activities": [
                      "activities",
                      "activities"
                    ],
                    "brands_detected": [
                      "brands_detected",
                      "brands_detected"
                    ],
                    "blur_level": "blur_level",
                    "saturation": "saturation",
                    "contrast": "contrast",
                    "brightness": "brightness",
                    "texture": [
                      "texture",
                      "texture"
                    ],
                    "quality_score": 1.1,
                    "view_count": 1,
                    "download_count": 1,
                    "source_url": "source_url",
                    "source_platform": "source_platform",
                    "sequence_order": 1,
                    "analysis_result": {
                      "analysis_result": {
                        "key": "value"
                      }
                    },
                    "thumbnails": [
                      "thumbnails",
                      "thumbnails"
                    ],
                    "id": "id",
                    "item_id": "item_id",
                    "created_at": "2024-01-15T09:30:00Z",
                    "updated_at": "2024-01-15T09:30:00Z",
                    "url": "url"
                  }
                ]
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = [
            MediaRead(
                filename: "filename",
                originalFilename: Optional("original_filename"),
                s3Key: "s3_key",
                fileSize: Optional(1),
                mediaType: .image,
                mimeType: Optional("mime_type"),
                width: Optional(1),
                height: Optional(1),
                duration: Optional(1.1),
                aspectRatio: Optional(1.1),
                title: Optional("title"),
                description: Optional("description"),
                altText: Optional("alt_text"),
                tags: Optional([
                    "tags",
                    "tags"
                ]),
                transcription: Optional("transcription"),
                extractedText: Optional("extracted_text"),
                detectedObjects: Optional([
                    "detected_objects",
                    "detected_objects"
                ]),
                colors: Optional([
                    "colors",
                    "colors"
                ]),
                mood: Optional("mood"),
                colorPalette: Optional([
                    "color_palette": Optional(1.1)
                ]),
                colorDistribution: Optional([
                    "color_distribution": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                colorTemperature: Optional("color_temperature"),
                colorHarmony: Optional("color_harmony"),
                dominantHue: Optional("dominant_hue"),
                colorVibrancy: Optional("color_vibrancy"),
                colorScheme: Optional("color_scheme"),
                style: Optional("style"),
                composition: Optional("composition"),
                lighting: Optional("lighting"),
                setting: Optional("setting"),
                peopleCount: Optional(1),
                facesDetected: Optional([
                    "faces_detected",
                    "faces_detected"
                ]),
                themes: Optional([
                    "themes",
                    "themes"
                ]),
                concepts: Optional([
                    "concepts",
                    "concepts"
                ]),
                activities: Optional([
                    "activities",
                    "activities"
                ]),
                brandsDetected: Optional([
                    "brands_detected",
                    "brands_detected"
                ]),
                blurLevel: Optional("blur_level"),
                saturation: Optional("saturation"),
                contrast: Optional("contrast"),
                brightness: Optional("brightness"),
                texture: Optional([
                    "texture",
                    "texture"
                ]),
                qualityScore: Optional(1.1),
                viewCount: Optional(1),
                downloadCount: Optional(1),
                sourceUrl: Optional("source_url"),
                sourcePlatform: Optional("source_platform"),
                sequenceOrder: Optional(1),
                analysisResult: Optional([
                    "analysis_result": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                thumbnails: Optional([
                    "thumbnails",
                    "thumbnails"
                ]),
                id: "id",
                itemId: "item_id",
                createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
                url: Optional("url")
            ),
            MediaRead(
                filename: "filename",
                originalFilename: Optional("original_filename"),
                s3Key: "s3_key",
                fileSize: Optional(1),
                mediaType: .image,
                mimeType: Optional("mime_type"),
                width: Optional(1),
                height: Optional(1),
                duration: Optional(1.1),
                aspectRatio: Optional(1.1),
                title: Optional("title"),
                description: Optional("description"),
                altText: Optional("alt_text"),
                tags: Optional([
                    "tags",
                    "tags"
                ]),
                transcription: Optional("transcription"),
                extractedText: Optional("extracted_text"),
                detectedObjects: Optional([
                    "detected_objects",
                    "detected_objects"
                ]),
                colors: Optional([
                    "colors",
                    "colors"
                ]),
                mood: Optional("mood"),
                colorPalette: Optional([
                    "color_palette": Optional(1.1)
                ]),
                colorDistribution: Optional([
                    "color_distribution": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                colorTemperature: Optional("color_temperature"),
                colorHarmony: Optional("color_harmony"),
                dominantHue: Optional("dominant_hue"),
                colorVibrancy: Optional("color_vibrancy"),
                colorScheme: Optional("color_scheme"),
                style: Optional("style"),
                composition: Optional("composition"),
                lighting: Optional("lighting"),
                setting: Optional("setting"),
                peopleCount: Optional(1),
                facesDetected: Optional([
                    "faces_detected",
                    "faces_detected"
                ]),
                themes: Optional([
                    "themes",
                    "themes"
                ]),
                concepts: Optional([
                    "concepts",
                    "concepts"
                ]),
                activities: Optional([
                    "activities",
                    "activities"
                ]),
                brandsDetected: Optional([
                    "brands_detected",
                    "brands_detected"
                ]),
                blurLevel: Optional("blur_level"),
                saturation: Optional("saturation"),
                contrast: Optional("contrast"),
                brightness: Optional("brightness"),
                texture: Optional([
                    "texture",
                    "texture"
                ]),
                qualityScore: Optional(1.1),
                viewCount: Optional(1),
                downloadCount: Optional(1),
                sourceUrl: Optional("source_url"),
                sourcePlatform: Optional("source_platform"),
                sequenceOrder: Optional(1),
                analysisResult: Optional([
                    "analysis_result": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                thumbnails: Optional([
                    "thumbnails",
                    "thumbnails"
                ]),
                id: "id",
                itemId: "item_id",
                createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
                url: Optional("url")
            )
        ]
        let response = try await client.media.listMedia()
        try #require(response == expectedResponse)
    }

    @Test func createMedia1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "filename": "filename",
                  "original_filename": "original_filename",
                  "s3_key": "s3_key",
                  "file_size": 1,
                  "media_type": "image",
                  "mime_type": "mime_type",
                  "width": 1,
                  "height": 1,
                  "duration": 1.1,
                  "aspect_ratio": 1.1,
                  "title": "title",
                  "description": "description",
                  "alt_text": "alt_text",
                  "tags": [
                    "tags"
                  ],
                  "transcription": "transcription",
                  "extracted_text": "extracted_text",
                  "detected_objects": [
                    "detected_objects"
                  ],
                  "colors": [
                    "colors"
                  ],
                  "mood": "mood",
                  "color_palette": {
                    "key": 1.1
                  },
                  "color_distribution": {
                    "key": "value"
                  },
                  "color_temperature": "color_temperature",
                  "color_harmony": "color_harmony",
                  "dominant_hue": "dominant_hue",
                  "color_vibrancy": "color_vibrancy",
                  "color_scheme": "color_scheme",
                  "style": "style",
                  "composition": "composition",
                  "lighting": "lighting",
                  "setting": "setting",
                  "people_count": 1,
                  "faces_detected": [
                    "faces_detected"
                  ],
                  "themes": [
                    "themes"
                  ],
                  "concepts": [
                    "concepts"
                  ],
                  "activities": [
                    "activities"
                  ],
                  "brands_detected": [
                    "brands_detected"
                  ],
                  "blur_level": "blur_level",
                  "saturation": "saturation",
                  "contrast": "contrast",
                  "brightness": "brightness",
                  "texture": [
                    "texture"
                  ],
                  "quality_score": 1.1,
                  "view_count": 1,
                  "download_count": 1,
                  "source_url": "source_url",
                  "source_platform": "source_platform",
                  "sequence_order": 1,
                  "analysis_result": {
                    "key": "value"
                  },
                  "thumbnails": [
                    "thumbnails"
                  ],
                  "id": "id",
                  "item_id": "item_id",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z",
                  "url": "url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = MediaRead(
            filename: "filename",
            originalFilename: Optional("original_filename"),
            s3Key: "s3_key",
            fileSize: Optional(1),
            mediaType: .image,
            mimeType: Optional("mime_type"),
            width: Optional(1),
            height: Optional(1),
            duration: Optional(1.1),
            aspectRatio: Optional(1.1),
            title: Optional("title"),
            description: Optional("description"),
            altText: Optional("alt_text"),
            tags: Optional([
                "tags"
            ]),
            transcription: Optional("transcription"),
            extractedText: Optional("extracted_text"),
            detectedObjects: Optional([
                "detected_objects"
            ]),
            colors: Optional([
                "colors"
            ]),
            mood: Optional("mood"),
            colorPalette: Optional([
                "key": Optional(1.1)
            ]),
            colorDistribution: Optional([
                "key": JSONValue.string("value")
            ]),
            colorTemperature: Optional("color_temperature"),
            colorHarmony: Optional("color_harmony"),
            dominantHue: Optional("dominant_hue"),
            colorVibrancy: Optional("color_vibrancy"),
            colorScheme: Optional("color_scheme"),
            style: Optional("style"),
            composition: Optional("composition"),
            lighting: Optional("lighting"),
            setting: Optional("setting"),
            peopleCount: Optional(1),
            facesDetected: Optional([
                "faces_detected"
            ]),
            themes: Optional([
                "themes"
            ]),
            concepts: Optional([
                "concepts"
            ]),
            activities: Optional([
                "activities"
            ]),
            brandsDetected: Optional([
                "brands_detected"
            ]),
            blurLevel: Optional("blur_level"),
            saturation: Optional("saturation"),
            contrast: Optional("contrast"),
            brightness: Optional("brightness"),
            texture: Optional([
                "texture"
            ]),
            qualityScore: Optional(1.1),
            viewCount: Optional(1),
            downloadCount: Optional(1),
            sourceUrl: Optional("source_url"),
            sourcePlatform: Optional("source_platform"),
            sequenceOrder: Optional(1),
            analysisResult: Optional([
                "key": JSONValue.string("value")
            ]),
            thumbnails: Optional([
                "thumbnails"
            ]),
            id: "id",
            itemId: "item_id",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
            url: Optional("url")
        )
        let response = try await client.media.createMedia(request: .init(
            filename: "filename",
            s3Key: "s3_key",
            mediaType: .image,
            itemId: "item_id"
        ))
        try #require(response == expectedResponse)
    }

    @Test func createMedia2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "filename": "filename",
                  "original_filename": "original_filename",
                  "s3_key": "s3_key",
                  "file_size": 1,
                  "media_type": "image",
                  "mime_type": "mime_type",
                  "width": 1,
                  "height": 1,
                  "duration": 1.1,
                  "aspect_ratio": 1.1,
                  "title": "title",
                  "description": "description",
                  "alt_text": "alt_text",
                  "tags": [
                    "tags",
                    "tags"
                  ],
                  "transcription": "transcription",
                  "extracted_text": "extracted_text",
                  "detected_objects": [
                    "detected_objects",
                    "detected_objects"
                  ],
                  "colors": [
                    "colors",
                    "colors"
                  ],
                  "mood": "mood",
                  "color_palette": {
                    "color_palette": 1.1
                  },
                  "color_distribution": {
                    "color_distribution": {
                      "key": "value"
                    }
                  },
                  "color_temperature": "color_temperature",
                  "color_harmony": "color_harmony",
                  "dominant_hue": "dominant_hue",
                  "color_vibrancy": "color_vibrancy",
                  "color_scheme": "color_scheme",
                  "style": "style",
                  "composition": "composition",
                  "lighting": "lighting",
                  "setting": "setting",
                  "people_count": 1,
                  "faces_detected": [
                    "faces_detected",
                    "faces_detected"
                  ],
                  "themes": [
                    "themes",
                    "themes"
                  ],
                  "concepts": [
                    "concepts",
                    "concepts"
                  ],
                  "activities": [
                    "activities",
                    "activities"
                  ],
                  "brands_detected": [
                    "brands_detected",
                    "brands_detected"
                  ],
                  "blur_level": "blur_level",
                  "saturation": "saturation",
                  "contrast": "contrast",
                  "brightness": "brightness",
                  "texture": [
                    "texture",
                    "texture"
                  ],
                  "quality_score": 1.1,
                  "view_count": 1,
                  "download_count": 1,
                  "source_url": "source_url",
                  "source_platform": "source_platform",
                  "sequence_order": 1,
                  "analysis_result": {
                    "analysis_result": {
                      "key": "value"
                    }
                  },
                  "thumbnails": [
                    "thumbnails",
                    "thumbnails"
                  ],
                  "id": "id",
                  "item_id": "item_id",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z",
                  "url": "url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = MediaRead(
            filename: "filename",
            originalFilename: Optional("original_filename"),
            s3Key: "s3_key",
            fileSize: Optional(1),
            mediaType: .image,
            mimeType: Optional("mime_type"),
            width: Optional(1),
            height: Optional(1),
            duration: Optional(1.1),
            aspectRatio: Optional(1.1),
            title: Optional("title"),
            description: Optional("description"),
            altText: Optional("alt_text"),
            tags: Optional([
                "tags",
                "tags"
            ]),
            transcription: Optional("transcription"),
            extractedText: Optional("extracted_text"),
            detectedObjects: Optional([
                "detected_objects",
                "detected_objects"
            ]),
            colors: Optional([
                "colors",
                "colors"
            ]),
            mood: Optional("mood"),
            colorPalette: Optional([
                "color_palette": Optional(1.1)
            ]),
            colorDistribution: Optional([
                "color_distribution": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            colorTemperature: Optional("color_temperature"),
            colorHarmony: Optional("color_harmony"),
            dominantHue: Optional("dominant_hue"),
            colorVibrancy: Optional("color_vibrancy"),
            colorScheme: Optional("color_scheme"),
            style: Optional("style"),
            composition: Optional("composition"),
            lighting: Optional("lighting"),
            setting: Optional("setting"),
            peopleCount: Optional(1),
            facesDetected: Optional([
                "faces_detected",
                "faces_detected"
            ]),
            themes: Optional([
                "themes",
                "themes"
            ]),
            concepts: Optional([
                "concepts",
                "concepts"
            ]),
            activities: Optional([
                "activities",
                "activities"
            ]),
            brandsDetected: Optional([
                "brands_detected",
                "brands_detected"
            ]),
            blurLevel: Optional("blur_level"),
            saturation: Optional("saturation"),
            contrast: Optional("contrast"),
            brightness: Optional("brightness"),
            texture: Optional([
                "texture",
                "texture"
            ]),
            qualityScore: Optional(1.1),
            viewCount: Optional(1),
            downloadCount: Optional(1),
            sourceUrl: Optional("source_url"),
            sourcePlatform: Optional("source_platform"),
            sequenceOrder: Optional(1),
            analysisResult: Optional([
                "analysis_result": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            thumbnails: Optional([
                "thumbnails",
                "thumbnails"
            ]),
            id: "id",
            itemId: "item_id",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
            url: Optional("url")
        )
        let response = try await client.media.createMedia(request: .init(
            filename: "filename",
            s3Key: "s3_key",
            mediaType: .image,
            itemId: "item_id"
        ))
        try #require(response == expectedResponse)
    }

    @Test func getMedia1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "filename": "filename",
                  "original_filename": "original_filename",
                  "s3_key": "s3_key",
                  "file_size": 1,
                  "media_type": "image",
                  "mime_type": "mime_type",
                  "width": 1,
                  "height": 1,
                  "duration": 1.1,
                  "aspect_ratio": 1.1,
                  "title": "title",
                  "description": "description",
                  "alt_text": "alt_text",
                  "tags": [
                    "tags"
                  ],
                  "transcription": "transcription",
                  "extracted_text": "extracted_text",
                  "detected_objects": [
                    "detected_objects"
                  ],
                  "colors": [
                    "colors"
                  ],
                  "mood": "mood",
                  "color_palette": {
                    "key": 1.1
                  },
                  "color_distribution": {
                    "key": "value"
                  },
                  "color_temperature": "color_temperature",
                  "color_harmony": "color_harmony",
                  "dominant_hue": "dominant_hue",
                  "color_vibrancy": "color_vibrancy",
                  "color_scheme": "color_scheme",
                  "style": "style",
                  "composition": "composition",
                  "lighting": "lighting",
                  "setting": "setting",
                  "people_count": 1,
                  "faces_detected": [
                    "faces_detected"
                  ],
                  "themes": [
                    "themes"
                  ],
                  "concepts": [
                    "concepts"
                  ],
                  "activities": [
                    "activities"
                  ],
                  "brands_detected": [
                    "brands_detected"
                  ],
                  "blur_level": "blur_level",
                  "saturation": "saturation",
                  "contrast": "contrast",
                  "brightness": "brightness",
                  "texture": [
                    "texture"
                  ],
                  "quality_score": 1.1,
                  "view_count": 1,
                  "download_count": 1,
                  "source_url": "source_url",
                  "source_platform": "source_platform",
                  "sequence_order": 1,
                  "analysis_result": {
                    "key": "value"
                  },
                  "thumbnails": [
                    "thumbnails"
                  ],
                  "id": "id",
                  "item_id": "item_id",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z",
                  "url": "url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = MediaRead(
            filename: "filename",
            originalFilename: Optional("original_filename"),
            s3Key: "s3_key",
            fileSize: Optional(1),
            mediaType: .image,
            mimeType: Optional("mime_type"),
            width: Optional(1),
            height: Optional(1),
            duration: Optional(1.1),
            aspectRatio: Optional(1.1),
            title: Optional("title"),
            description: Optional("description"),
            altText: Optional("alt_text"),
            tags: Optional([
                "tags"
            ]),
            transcription: Optional("transcription"),
            extractedText: Optional("extracted_text"),
            detectedObjects: Optional([
                "detected_objects"
            ]),
            colors: Optional([
                "colors"
            ]),
            mood: Optional("mood"),
            colorPalette: Optional([
                "key": Optional(1.1)
            ]),
            colorDistribution: Optional([
                "key": JSONValue.string("value")
            ]),
            colorTemperature: Optional("color_temperature"),
            colorHarmony: Optional("color_harmony"),
            dominantHue: Optional("dominant_hue"),
            colorVibrancy: Optional("color_vibrancy"),
            colorScheme: Optional("color_scheme"),
            style: Optional("style"),
            composition: Optional("composition"),
            lighting: Optional("lighting"),
            setting: Optional("setting"),
            peopleCount: Optional(1),
            facesDetected: Optional([
                "faces_detected"
            ]),
            themes: Optional([
                "themes"
            ]),
            concepts: Optional([
                "concepts"
            ]),
            activities: Optional([
                "activities"
            ]),
            brandsDetected: Optional([
                "brands_detected"
            ]),
            blurLevel: Optional("blur_level"),
            saturation: Optional("saturation"),
            contrast: Optional("contrast"),
            brightness: Optional("brightness"),
            texture: Optional([
                "texture"
            ]),
            qualityScore: Optional(1.1),
            viewCount: Optional(1),
            downloadCount: Optional(1),
            sourceUrl: Optional("source_url"),
            sourcePlatform: Optional("source_platform"),
            sequenceOrder: Optional(1),
            analysisResult: Optional([
                "key": JSONValue.string("value")
            ]),
            thumbnails: Optional([
                "thumbnails"
            ]),
            id: "id",
            itemId: "item_id",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
            url: Optional("url")
        )
        let response = try await client.media.getMedia(mediaId: "media_id")
        try #require(response == expectedResponse)
    }

    @Test func getMedia2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "filename": "filename",
                  "original_filename": "original_filename",
                  "s3_key": "s3_key",
                  "file_size": 1,
                  "media_type": "image",
                  "mime_type": "mime_type",
                  "width": 1,
                  "height": 1,
                  "duration": 1.1,
                  "aspect_ratio": 1.1,
                  "title": "title",
                  "description": "description",
                  "alt_text": "alt_text",
                  "tags": [
                    "tags",
                    "tags"
                  ],
                  "transcription": "transcription",
                  "extracted_text": "extracted_text",
                  "detected_objects": [
                    "detected_objects",
                    "detected_objects"
                  ],
                  "colors": [
                    "colors",
                    "colors"
                  ],
                  "mood": "mood",
                  "color_palette": {
                    "color_palette": 1.1
                  },
                  "color_distribution": {
                    "color_distribution": {
                      "key": "value"
                    }
                  },
                  "color_temperature": "color_temperature",
                  "color_harmony": "color_harmony",
                  "dominant_hue": "dominant_hue",
                  "color_vibrancy": "color_vibrancy",
                  "color_scheme": "color_scheme",
                  "style": "style",
                  "composition": "composition",
                  "lighting": "lighting",
                  "setting": "setting",
                  "people_count": 1,
                  "faces_detected": [
                    "faces_detected",
                    "faces_detected"
                  ],
                  "themes": [
                    "themes",
                    "themes"
                  ],
                  "concepts": [
                    "concepts",
                    "concepts"
                  ],
                  "activities": [
                    "activities",
                    "activities"
                  ],
                  "brands_detected": [
                    "brands_detected",
                    "brands_detected"
                  ],
                  "blur_level": "blur_level",
                  "saturation": "saturation",
                  "contrast": "contrast",
                  "brightness": "brightness",
                  "texture": [
                    "texture",
                    "texture"
                  ],
                  "quality_score": 1.1,
                  "view_count": 1,
                  "download_count": 1,
                  "source_url": "source_url",
                  "source_platform": "source_platform",
                  "sequence_order": 1,
                  "analysis_result": {
                    "analysis_result": {
                      "key": "value"
                    }
                  },
                  "thumbnails": [
                    "thumbnails",
                    "thumbnails"
                  ],
                  "id": "id",
                  "item_id": "item_id",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z",
                  "url": "url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = MediaRead(
            filename: "filename",
            originalFilename: Optional("original_filename"),
            s3Key: "s3_key",
            fileSize: Optional(1),
            mediaType: .image,
            mimeType: Optional("mime_type"),
            width: Optional(1),
            height: Optional(1),
            duration: Optional(1.1),
            aspectRatio: Optional(1.1),
            title: Optional("title"),
            description: Optional("description"),
            altText: Optional("alt_text"),
            tags: Optional([
                "tags",
                "tags"
            ]),
            transcription: Optional("transcription"),
            extractedText: Optional("extracted_text"),
            detectedObjects: Optional([
                "detected_objects",
                "detected_objects"
            ]),
            colors: Optional([
                "colors",
                "colors"
            ]),
            mood: Optional("mood"),
            colorPalette: Optional([
                "color_palette": Optional(1.1)
            ]),
            colorDistribution: Optional([
                "color_distribution": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            colorTemperature: Optional("color_temperature"),
            colorHarmony: Optional("color_harmony"),
            dominantHue: Optional("dominant_hue"),
            colorVibrancy: Optional("color_vibrancy"),
            colorScheme: Optional("color_scheme"),
            style: Optional("style"),
            composition: Optional("composition"),
            lighting: Optional("lighting"),
            setting: Optional("setting"),
            peopleCount: Optional(1),
            facesDetected: Optional([
                "faces_detected",
                "faces_detected"
            ]),
            themes: Optional([
                "themes",
                "themes"
            ]),
            concepts: Optional([
                "concepts",
                "concepts"
            ]),
            activities: Optional([
                "activities",
                "activities"
            ]),
            brandsDetected: Optional([
                "brands_detected",
                "brands_detected"
            ]),
            blurLevel: Optional("blur_level"),
            saturation: Optional("saturation"),
            contrast: Optional("contrast"),
            brightness: Optional("brightness"),
            texture: Optional([
                "texture",
                "texture"
            ]),
            qualityScore: Optional(1.1),
            viewCount: Optional(1),
            downloadCount: Optional(1),
            sourceUrl: Optional("source_url"),
            sourcePlatform: Optional("source_platform"),
            sequenceOrder: Optional(1),
            analysisResult: Optional([
                "analysis_result": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            thumbnails: Optional([
                "thumbnails",
                "thumbnails"
            ]),
            id: "id",
            itemId: "item_id",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
            url: Optional("url")
        )
        let response = try await client.media.getMedia(mediaId: "media_id")
        try #require(response == expectedResponse)
    }

    @Test func updateMedia1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "filename": "filename",
                  "original_filename": "original_filename",
                  "s3_key": "s3_key",
                  "file_size": 1,
                  "media_type": "image",
                  "mime_type": "mime_type",
                  "width": 1,
                  "height": 1,
                  "duration": 1.1,
                  "aspect_ratio": 1.1,
                  "title": "title",
                  "description": "description",
                  "alt_text": "alt_text",
                  "tags": [
                    "tags"
                  ],
                  "transcription": "transcription",
                  "extracted_text": "extracted_text",
                  "detected_objects": [
                    "detected_objects"
                  ],
                  "colors": [
                    "colors"
                  ],
                  "mood": "mood",
                  "color_palette": {
                    "key": 1.1
                  },
                  "color_distribution": {
                    "key": "value"
                  },
                  "color_temperature": "color_temperature",
                  "color_harmony": "color_harmony",
                  "dominant_hue": "dominant_hue",
                  "color_vibrancy": "color_vibrancy",
                  "color_scheme": "color_scheme",
                  "style": "style",
                  "composition": "composition",
                  "lighting": "lighting",
                  "setting": "setting",
                  "people_count": 1,
                  "faces_detected": [
                    "faces_detected"
                  ],
                  "themes": [
                    "themes"
                  ],
                  "concepts": [
                    "concepts"
                  ],
                  "activities": [
                    "activities"
                  ],
                  "brands_detected": [
                    "brands_detected"
                  ],
                  "blur_level": "blur_level",
                  "saturation": "saturation",
                  "contrast": "contrast",
                  "brightness": "brightness",
                  "texture": [
                    "texture"
                  ],
                  "quality_score": 1.1,
                  "view_count": 1,
                  "download_count": 1,
                  "source_url": "source_url",
                  "source_platform": "source_platform",
                  "sequence_order": 1,
                  "analysis_result": {
                    "key": "value"
                  },
                  "thumbnails": [
                    "thumbnails"
                  ],
                  "id": "id",
                  "item_id": "item_id",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z",
                  "url": "url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = MediaRead(
            filename: "filename",
            originalFilename: Optional("original_filename"),
            s3Key: "s3_key",
            fileSize: Optional(1),
            mediaType: .image,
            mimeType: Optional("mime_type"),
            width: Optional(1),
            height: Optional(1),
            duration: Optional(1.1),
            aspectRatio: Optional(1.1),
            title: Optional("title"),
            description: Optional("description"),
            altText: Optional("alt_text"),
            tags: Optional([
                "tags"
            ]),
            transcription: Optional("transcription"),
            extractedText: Optional("extracted_text"),
            detectedObjects: Optional([
                "detected_objects"
            ]),
            colors: Optional([
                "colors"
            ]),
            mood: Optional("mood"),
            colorPalette: Optional([
                "key": Optional(1.1)
            ]),
            colorDistribution: Optional([
                "key": JSONValue.string("value")
            ]),
            colorTemperature: Optional("color_temperature"),
            colorHarmony: Optional("color_harmony"),
            dominantHue: Optional("dominant_hue"),
            colorVibrancy: Optional("color_vibrancy"),
            colorScheme: Optional("color_scheme"),
            style: Optional("style"),
            composition: Optional("composition"),
            lighting: Optional("lighting"),
            setting: Optional("setting"),
            peopleCount: Optional(1),
            facesDetected: Optional([
                "faces_detected"
            ]),
            themes: Optional([
                "themes"
            ]),
            concepts: Optional([
                "concepts"
            ]),
            activities: Optional([
                "activities"
            ]),
            brandsDetected: Optional([
                "brands_detected"
            ]),
            blurLevel: Optional("blur_level"),
            saturation: Optional("saturation"),
            contrast: Optional("contrast"),
            brightness: Optional("brightness"),
            texture: Optional([
                "texture"
            ]),
            qualityScore: Optional(1.1),
            viewCount: Optional(1),
            downloadCount: Optional(1),
            sourceUrl: Optional("source_url"),
            sourcePlatform: Optional("source_platform"),
            sequenceOrder: Optional(1),
            analysisResult: Optional([
                "key": JSONValue.string("value")
            ]),
            thumbnails: Optional([
                "thumbnails"
            ]),
            id: "id",
            itemId: "item_id",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
            url: Optional("url")
        )
        let response = try await client.media.updateMedia(
            mediaId: "media_id",
            request: .init()
        )
        try #require(response == expectedResponse)
    }

    @Test func updateMedia2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "filename": "filename",
                  "original_filename": "original_filename",
                  "s3_key": "s3_key",
                  "file_size": 1,
                  "media_type": "image",
                  "mime_type": "mime_type",
                  "width": 1,
                  "height": 1,
                  "duration": 1.1,
                  "aspect_ratio": 1.1,
                  "title": "title",
                  "description": "description",
                  "alt_text": "alt_text",
                  "tags": [
                    "tags",
                    "tags"
                  ],
                  "transcription": "transcription",
                  "extracted_text": "extracted_text",
                  "detected_objects": [
                    "detected_objects",
                    "detected_objects"
                  ],
                  "colors": [
                    "colors",
                    "colors"
                  ],
                  "mood": "mood",
                  "color_palette": {
                    "color_palette": 1.1
                  },
                  "color_distribution": {
                    "color_distribution": {
                      "key": "value"
                    }
                  },
                  "color_temperature": "color_temperature",
                  "color_harmony": "color_harmony",
                  "dominant_hue": "dominant_hue",
                  "color_vibrancy": "color_vibrancy",
                  "color_scheme": "color_scheme",
                  "style": "style",
                  "composition": "composition",
                  "lighting": "lighting",
                  "setting": "setting",
                  "people_count": 1,
                  "faces_detected": [
                    "faces_detected",
                    "faces_detected"
                  ],
                  "themes": [
                    "themes",
                    "themes"
                  ],
                  "concepts": [
                    "concepts",
                    "concepts"
                  ],
                  "activities": [
                    "activities",
                    "activities"
                  ],
                  "brands_detected": [
                    "brands_detected",
                    "brands_detected"
                  ],
                  "blur_level": "blur_level",
                  "saturation": "saturation",
                  "contrast": "contrast",
                  "brightness": "brightness",
                  "texture": [
                    "texture",
                    "texture"
                  ],
                  "quality_score": 1.1,
                  "view_count": 1,
                  "download_count": 1,
                  "source_url": "source_url",
                  "source_platform": "source_platform",
                  "sequence_order": 1,
                  "analysis_result": {
                    "analysis_result": {
                      "key": "value"
                    }
                  },
                  "thumbnails": [
                    "thumbnails",
                    "thumbnails"
                  ],
                  "id": "id",
                  "item_id": "item_id",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z",
                  "url": "url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = MediaRead(
            filename: "filename",
            originalFilename: Optional("original_filename"),
            s3Key: "s3_key",
            fileSize: Optional(1),
            mediaType: .image,
            mimeType: Optional("mime_type"),
            width: Optional(1),
            height: Optional(1),
            duration: Optional(1.1),
            aspectRatio: Optional(1.1),
            title: Optional("title"),
            description: Optional("description"),
            altText: Optional("alt_text"),
            tags: Optional([
                "tags",
                "tags"
            ]),
            transcription: Optional("transcription"),
            extractedText: Optional("extracted_text"),
            detectedObjects: Optional([
                "detected_objects",
                "detected_objects"
            ]),
            colors: Optional([
                "colors",
                "colors"
            ]),
            mood: Optional("mood"),
            colorPalette: Optional([
                "color_palette": Optional(1.1)
            ]),
            colorDistribution: Optional([
                "color_distribution": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            colorTemperature: Optional("color_temperature"),
            colorHarmony: Optional("color_harmony"),
            dominantHue: Optional("dominant_hue"),
            colorVibrancy: Optional("color_vibrancy"),
            colorScheme: Optional("color_scheme"),
            style: Optional("style"),
            composition: Optional("composition"),
            lighting: Optional("lighting"),
            setting: Optional("setting"),
            peopleCount: Optional(1),
            facesDetected: Optional([
                "faces_detected",
                "faces_detected"
            ]),
            themes: Optional([
                "themes",
                "themes"
            ]),
            concepts: Optional([
                "concepts",
                "concepts"
            ]),
            activities: Optional([
                "activities",
                "activities"
            ]),
            brandsDetected: Optional([
                "brands_detected",
                "brands_detected"
            ]),
            blurLevel: Optional("blur_level"),
            saturation: Optional("saturation"),
            contrast: Optional("contrast"),
            brightness: Optional("brightness"),
            texture: Optional([
                "texture",
                "texture"
            ]),
            qualityScore: Optional(1.1),
            viewCount: Optional(1),
            downloadCount: Optional(1),
            sourceUrl: Optional("source_url"),
            sourcePlatform: Optional("source_platform"),
            sequenceOrder: Optional(1),
            analysisResult: Optional([
                "analysis_result": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            thumbnails: Optional([
                "thumbnails",
                "thumbnails"
            ]),
            id: "id",
            itemId: "item_id",
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: Optional(try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)),
            url: Optional("url")
        )
        let response = try await client.media.updateMedia(
            mediaId: "media_id",
            request: .init()
        )
        try #require(response == expectedResponse)
    }
}