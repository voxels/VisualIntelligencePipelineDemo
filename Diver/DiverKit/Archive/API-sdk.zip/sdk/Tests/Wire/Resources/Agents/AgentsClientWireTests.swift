import Foundation
import Testing
import Api

@Suite("AgentsClient Wire Tests") struct AgentsClientWireTests {
    @Test func registerAgent1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "agent_id": "agent_id",
                  "name": "name",
                  "purpose": "purpose",
                  "version": "version",
                  "hostname": "hostname",
                  "pid": 1,
                  "capabilities": [
                    "capabilities"
                  ],
                  "pydantic_schema": {
                    "key": "value"
                  },
                  "status": "status",
                  "uptime": 1.1,
                  "memory_usage": {
                    "key": "value"
                  },
                  "queue_stats": {
                    "key": "value"
                  },
                  "last_heartbeat": "2024-01-15T09:30:00Z",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = AgentRead(
            agentId: "agent_id",
            name: "name",
            purpose: "purpose",
            version: "version",
            hostname: "hostname",
            pid: 1,
            capabilities: [
                "capabilities"
            ],
            pydanticSchema: [
                "key": JSONValue.string("value")
            ],
            status: "status",
            uptime: 1.1,
            memoryUsage: Optional([
                "key": JSONValue.string("value")
            ]),
            queueStats: Optional([
                "key": JSONValue.string("value")
            ]),
            lastHeartbeat: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)
        )
        let response = try await client.agents.registerAgent(request: .init(
            name: "name",
            purpose: "purpose",
            version: "version",
            hostname: "hostname",
            pid: 1,
            capabilities: [
                "capabilities"
            ],
            pydanticSchema: [
                "key": .string("value")
            ]
        ))
        try #require(response == expectedResponse)
    }

    @Test func registerAgent2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "agent_id": "agent_id",
                  "name": "name",
                  "purpose": "purpose",
                  "version": "version",
                  "hostname": "hostname",
                  "pid": 1,
                  "capabilities": [
                    "capabilities",
                    "capabilities"
                  ],
                  "pydantic_schema": {
                    "pydantic_schema": {
                      "key": "value"
                    }
                  },
                  "status": "status",
                  "uptime": 1.1,
                  "memory_usage": {
                    "memory_usage": {
                      "key": "value"
                    }
                  },
                  "queue_stats": {
                    "queue_stats": {
                      "key": "value"
                    }
                  },
                  "last_heartbeat": "2024-01-15T09:30:00Z",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = AgentRead(
            agentId: "agent_id",
            name: "name",
            purpose: "purpose",
            version: "version",
            hostname: "hostname",
            pid: 1,
            capabilities: [
                "capabilities",
                "capabilities"
            ],
            pydanticSchema: [
                "pydantic_schema": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ],
            status: "status",
            uptime: 1.1,
            memoryUsage: Optional([
                "memory_usage": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            queueStats: Optional([
                "queue_stats": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            lastHeartbeat: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)
        )
        let response = try await client.agents.registerAgent(request: .init(
            name: "name",
            purpose: "purpose",
            version: "version",
            hostname: "hostname",
            pid: 1,
            capabilities: [
                "capabilities",
                "capabilities"
            ],
            pydanticSchema: [
                "pydantic_schema": .object([
                    "key": .string("value")
                ])
            ]
        ))
        try #require(response == expectedResponse)
    }

    @Test func listAgents1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                [
                  {
                    "agent_id": "agent_id",
                    "name": "name",
                    "purpose": "purpose",
                    "version": "version",
                    "hostname": "hostname",
                    "pid": 1,
                    "capabilities": [
                      "capabilities"
                    ],
                    "pydantic_schema": {
                      "key": "value"
                    },
                    "status": "status",
                    "uptime": 1.1,
                    "memory_usage": {
                      "key": "value"
                    },
                    "queue_stats": {
                      "key": "value"
                    },
                    "last_heartbeat": "2024-01-15T09:30:00Z",
                    "created_at": "2024-01-15T09:30:00Z",
                    "updated_at": "2024-01-15T09:30:00Z"
                  }
                ]
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = [
            AgentRead(
                agentId: "agent_id",
                name: "name",
                purpose: "purpose",
                version: "version",
                hostname: "hostname",
                pid: 1,
                capabilities: [
                    "capabilities"
                ],
                pydanticSchema: [
                    "key": JSONValue.string("value")
                ],
                status: "status",
                uptime: 1.1,
                memoryUsage: Optional([
                    "key": JSONValue.string("value")
                ]),
                queueStats: Optional([
                    "key": JSONValue.string("value")
                ]),
                lastHeartbeat: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                updatedAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)
            )
        ]
        let response = try await client.agents.listAgents()
        try #require(response == expectedResponse)
    }

    @Test func listAgents2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                [
                  {
                    "agent_id": "agent_id",
                    "name": "name",
                    "purpose": "purpose",
                    "version": "version",
                    "hostname": "hostname",
                    "pid": 1,
                    "capabilities": [
                      "capabilities",
                      "capabilities"
                    ],
                    "pydantic_schema": {
                      "pydantic_schema": {
                        "key": "value"
                      }
                    },
                    "status": "status",
                    "uptime": 1.1,
                    "memory_usage": {
                      "memory_usage": {
                        "key": "value"
                      }
                    },
                    "queue_stats": {
                      "queue_stats": {
                        "key": "value"
                      }
                    },
                    "last_heartbeat": "2024-01-15T09:30:00Z",
                    "created_at": "2024-01-15T09:30:00Z",
                    "updated_at": "2024-01-15T09:30:00Z"
                  },
                  {
                    "agent_id": "agent_id",
                    "name": "name",
                    "purpose": "purpose",
                    "version": "version",
                    "hostname": "hostname",
                    "pid": 1,
                    "capabilities": [
                      "capabilities",
                      "capabilities"
                    ],
                    "pydantic_schema": {
                      "pydantic_schema": {
                        "key": "value"
                      }
                    },
                    "status": "status",
                    "uptime": 1.1,
                    "memory_usage": {
                      "memory_usage": {
                        "key": "value"
                      }
                    },
                    "queue_stats": {
                      "queue_stats": {
                        "key": "value"
                      }
                    },
                    "last_heartbeat": "2024-01-15T09:30:00Z",
                    "created_at": "2024-01-15T09:30:00Z",
                    "updated_at": "2024-01-15T09:30:00Z"
                  }
                ]
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = [
            AgentRead(
                agentId: "agent_id",
                name: "name",
                purpose: "purpose",
                version: "version",
                hostname: "hostname",
                pid: 1,
                capabilities: [
                    "capabilities",
                    "capabilities"
                ],
                pydanticSchema: [
                    "pydantic_schema": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ],
                status: "status",
                uptime: 1.1,
                memoryUsage: Optional([
                    "memory_usage": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                queueStats: Optional([
                    "queue_stats": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                lastHeartbeat: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                updatedAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)
            ),
            AgentRead(
                agentId: "agent_id",
                name: "name",
                purpose: "purpose",
                version: "version",
                hostname: "hostname",
                pid: 1,
                capabilities: [
                    "capabilities",
                    "capabilities"
                ],
                pydanticSchema: [
                    "pydantic_schema": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ],
                status: "status",
                uptime: 1.1,
                memoryUsage: Optional([
                    "memory_usage": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                queueStats: Optional([
                    "queue_stats": JSONValue.object(
                        [
                            "key": JSONValue.string("value")
                        ]
                    )
                ]),
                lastHeartbeat: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
                updatedAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)
            )
        ]
        let response = try await client.agents.listAgents()
        try #require(response == expectedResponse)
    }

    @Test func getAgent1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "agent_id": "agent_id",
                  "name": "name",
                  "purpose": "purpose",
                  "version": "version",
                  "hostname": "hostname",
                  "pid": 1,
                  "capabilities": [
                    "capabilities"
                  ],
                  "pydantic_schema": {
                    "key": "value"
                  },
                  "status": "status",
                  "uptime": 1.1,
                  "memory_usage": {
                    "key": "value"
                  },
                  "queue_stats": {
                    "key": "value"
                  },
                  "last_heartbeat": "2024-01-15T09:30:00Z",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = AgentRead(
            agentId: "agent_id",
            name: "name",
            purpose: "purpose",
            version: "version",
            hostname: "hostname",
            pid: 1,
            capabilities: [
                "capabilities"
            ],
            pydanticSchema: [
                "key": JSONValue.string("value")
            ],
            status: "status",
            uptime: 1.1,
            memoryUsage: Optional([
                "key": JSONValue.string("value")
            ]),
            queueStats: Optional([
                "key": JSONValue.string("value")
            ]),
            lastHeartbeat: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)
        )
        let response = try await client.agents.getAgent(agentId: "agent_id")
        try #require(response == expectedResponse)
    }

    @Test func getAgent2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "agent_id": "agent_id",
                  "name": "name",
                  "purpose": "purpose",
                  "version": "version",
                  "hostname": "hostname",
                  "pid": 1,
                  "capabilities": [
                    "capabilities",
                    "capabilities"
                  ],
                  "pydantic_schema": {
                    "pydantic_schema": {
                      "key": "value"
                    }
                  },
                  "status": "status",
                  "uptime": 1.1,
                  "memory_usage": {
                    "memory_usage": {
                      "key": "value"
                    }
                  },
                  "queue_stats": {
                    "queue_stats": {
                      "key": "value"
                    }
                  },
                  "last_heartbeat": "2024-01-15T09:30:00Z",
                  "created_at": "2024-01-15T09:30:00Z",
                  "updated_at": "2024-01-15T09:30:00Z"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = AgentRead(
            agentId: "agent_id",
            name: "name",
            purpose: "purpose",
            version: "version",
            hostname: "hostname",
            pid: 1,
            capabilities: [
                "capabilities",
                "capabilities"
            ],
            pydanticSchema: [
                "pydantic_schema": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ],
            status: "status",
            uptime: 1.1,
            memoryUsage: Optional([
                "memory_usage": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            queueStats: Optional([
                "queue_stats": JSONValue.object(
                    [
                        "key": JSONValue.string("value")
                    ]
                )
            ]),
            lastHeartbeat: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            createdAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601),
            updatedAt: try! Date("2024-01-15T09:30:00Z", strategy: .iso8601)
        )
        let response = try await client.agents.getAgent(agentId: "agent_id")
        try #require(response == expectedResponse)
    }

    @Test func deregisterAgent1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.agents.deregisterAgent(agentId: "agent_id")
        try #require(response == expectedResponse)
    }

    @Test func deregisterAgent2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.agents.deregisterAgent(agentId: "agent_id")
        try #require(response == expectedResponse)
    }
}