import Foundation
import Testing
import Api

@Suite("JobsClient Wire Tests") struct JobsClientWireTests {
    @Test func streamJobProgress1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.jobs.streamJobProgress(jobUuid: "job_uuid")
        try #require(response == expectedResponse)
    }

    @Test func streamJobProgress2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.jobs.streamJobProgress(jobUuid: "job_uuid")
        try #require(response == expectedResponse)
    }
}