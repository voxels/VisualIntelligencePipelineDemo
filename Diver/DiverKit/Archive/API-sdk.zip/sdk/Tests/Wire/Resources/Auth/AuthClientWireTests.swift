import Foundation
import Testing
import Api

@Suite("AuthClient Wire Tests") struct AuthClientWireTests {
    @Test func authJwtLogin1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "access_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiOTIyMWZmYzktNjQwZi00MzcyLTg2ZDMtY2U2NDJjYmE1NjAzIiwiYXVkIjoiZmFzdGFwaS11c2VyczphdXRoIiwiZXhwIjoxNTcxNTA0MTkzfQ.M10bjOe45I5Ncu_uXvOmVV8QxnL-nZfcH96U90JaocI",
                  "token_type": "bearer"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = BearerResponse(
            accessToken: "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1c2VyX2lkIjoiOTIyMWZmYzktNjQwZi00MzcyLTg2ZDMtY2U2NDJjYmE1NjAzIiwiYXVkIjoiZmFzdGFwaS11c2VyczphdXRoIiwiZXhwIjoxNTcxNTA0MTkzfQ.M10bjOe45I5Ncu_uXvOmVV8QxnL-nZfcH96U90JaocI",
            tokenType: "bearer"
        )
        let response = try await client.auth.authJwtLogin(request: BodyAuthJwtLoginAuthJwtLoginPost(
            username: "username",
            password: "password"
        ))
        try #require(response == expectedResponse)
    }

    @Test func authJwtLogin2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "access_token": "access_token",
                  "token_type": "token_type"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = BearerResponse(
            accessToken: "access_token",
            tokenType: "token_type"
        )
        let response = try await client.auth.authJwtLogin(request: BodyAuthJwtLoginAuthJwtLoginPost(
            username: "username",
            password: "password"
        ))
        try #require(response == expectedResponse)
    }

    @Test func authJwtLogout1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.auth.authJwtLogout()
        try #require(response == expectedResponse)
    }

    @Test func authJwtLogout2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.auth.authJwtLogout()
        try #require(response == expectedResponse)
    }

    @Test func registerRegister1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "id": "id",
                  "email": "email",
                  "is_active": true,
                  "is_superuser": true,
                  "is_verified": true,
                  "username": "username",
                  "phone": "phone",
                  "first_name": "first_name",
                  "last_name": "last_name",
                  "bio": "bio",
                  "timezone": "timezone",
                  "language": "language",
                  "profile_public": true,
                  "allow_notifications": true,
                  "avatar_url": "avatar_url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = UserRead(
            id: "id",
            email: "email",
            isActive: Optional(true),
            isSuperuser: Optional(true),
            isVerified: Optional(true),
            username: Optional("username"),
            phone: Optional("phone"),
            firstName: Optional("first_name"),
            lastName: Optional("last_name"),
            bio: Optional("bio"),
            timezone: Optional("timezone"),
            language: Optional("language"),
            profilePublic: Optional(true),
            allowNotifications: Optional(true),
            avatarUrl: Optional("avatar_url")
        )
        let response = try await client.auth.registerRegister(request: .init(
            email: "email",
            password: "password"
        ))
        try #require(response == expectedResponse)
    }

    @Test func registerRegister2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "id": "id",
                  "email": "email",
                  "is_active": true,
                  "is_superuser": true,
                  "is_verified": true,
                  "username": "username",
                  "phone": "phone",
                  "first_name": "first_name",
                  "last_name": "last_name",
                  "bio": "bio",
                  "timezone": "timezone",
                  "language": "language",
                  "profile_public": true,
                  "allow_notifications": true,
                  "avatar_url": "avatar_url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = UserRead(
            id: "id",
            email: "email",
            isActive: Optional(true),
            isSuperuser: Optional(true),
            isVerified: Optional(true),
            username: Optional("username"),
            phone: Optional("phone"),
            firstName: Optional("first_name"),
            lastName: Optional("last_name"),
            bio: Optional("bio"),
            timezone: Optional("timezone"),
            language: Optional("language"),
            profilePublic: Optional(true),
            allowNotifications: Optional(true),
            avatarUrl: Optional("avatar_url")
        )
        let response = try await client.auth.registerRegister(request: .init(
            email: "email",
            password: "password"
        ))
        try #require(response == expectedResponse)
    }

    @Test func resetForgotPassword1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.auth.resetForgotPassword(request: .init(email: "email"))
        try #require(response == expectedResponse)
    }

    @Test func resetForgotPassword2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.auth.resetForgotPassword(request: .init(email: "email"))
        try #require(response == expectedResponse)
    }

    @Test func resetResetPassword1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.auth.resetResetPassword(request: .init(
            token: "token",
            password: "password"
        ))
        try #require(response == expectedResponse)
    }

    @Test func resetResetPassword2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.auth.resetResetPassword(request: .init(
            token: "token",
            password: "password"
        ))
        try #require(response == expectedResponse)
    }

    @Test func verifyRequestToken1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.auth.verifyRequestToken(request: .init(email: "email"))
        try #require(response == expectedResponse)
    }

    @Test func verifyRequestToken2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.auth.verifyRequestToken(request: .init(email: "email"))
        try #require(response == expectedResponse)
    }

    @Test func verifyVerify1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "id": "id",
                  "email": "email",
                  "is_active": true,
                  "is_superuser": true,
                  "is_verified": true,
                  "username": "username",
                  "phone": "phone",
                  "first_name": "first_name",
                  "last_name": "last_name",
                  "bio": "bio",
                  "timezone": "timezone",
                  "language": "language",
                  "profile_public": true,
                  "allow_notifications": true,
                  "avatar_url": "avatar_url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = UserRead(
            id: "id",
            email: "email",
            isActive: Optional(true),
            isSuperuser: Optional(true),
            isVerified: Optional(true),
            username: Optional("username"),
            phone: Optional("phone"),
            firstName: Optional("first_name"),
            lastName: Optional("last_name"),
            bio: Optional("bio"),
            timezone: Optional("timezone"),
            language: Optional("language"),
            profilePublic: Optional(true),
            allowNotifications: Optional(true),
            avatarUrl: Optional("avatar_url")
        )
        let response = try await client.auth.verifyVerify(request: .init(token: "token"))
        try #require(response == expectedResponse)
    }

    @Test func verifyVerify2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "id": "id",
                  "email": "email",
                  "is_active": true,
                  "is_superuser": true,
                  "is_verified": true,
                  "username": "username",
                  "phone": "phone",
                  "first_name": "first_name",
                  "last_name": "last_name",
                  "bio": "bio",
                  "timezone": "timezone",
                  "language": "language",
                  "profile_public": true,
                  "allow_notifications": true,
                  "avatar_url": "avatar_url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = UserRead(
            id: "id",
            email: "email",
            isActive: Optional(true),
            isSuperuser: Optional(true),
            isVerified: Optional(true),
            username: Optional("username"),
            phone: Optional("phone"),
            firstName: Optional("first_name"),
            lastName: Optional("last_name"),
            bio: Optional("bio"),
            timezone: Optional("timezone"),
            language: Optional("language"),
            profilePublic: Optional(true),
            allowNotifications: Optional(true),
            avatarUrl: Optional("avatar_url")
        )
        let response = try await client.auth.verifyVerify(request: .init(token: "token"))
        try #require(response == expectedResponse)
    }

    @Test func exchangeApiKeyForToken1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.auth.exchangeApiKeyForToken()
        try #require(response == expectedResponse)
    }

    @Test func exchangeApiKeyForToken2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "key": "value"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = JSONValue.object(
            [
                "key": JSONValue.string("value")
            ]
        )
        let response = try await client.auth.exchangeApiKeyForToken()
        try #require(response == expectedResponse)
    }

    @Test func usersCurrentUser1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "id": "id",
                  "email": "email",
                  "is_active": true,
                  "is_superuser": true,
                  "is_verified": true,
                  "username": "username",
                  "phone": "phone",
                  "first_name": "first_name",
                  "last_name": "last_name",
                  "bio": "bio",
                  "timezone": "timezone",
                  "language": "language",
                  "profile_public": true,
                  "allow_notifications": true,
                  "avatar_url": "avatar_url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = UserRead(
            id: "id",
            email: "email",
            isActive: Optional(true),
            isSuperuser: Optional(true),
            isVerified: Optional(true),
            username: Optional("username"),
            phone: Optional("phone"),
            firstName: Optional("first_name"),
            lastName: Optional("last_name"),
            bio: Optional("bio"),
            timezone: Optional("timezone"),
            language: Optional("language"),
            profilePublic: Optional(true),
            allowNotifications: Optional(true),
            avatarUrl: Optional("avatar_url")
        )
        let response = try await client.auth.usersCurrentUser()
        try #require(response == expectedResponse)
    }

    @Test func usersCurrentUser2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "id": "id",
                  "email": "email",
                  "is_active": true,
                  "is_superuser": true,
                  "is_verified": true,
                  "username": "username",
                  "phone": "phone",
                  "first_name": "first_name",
                  "last_name": "last_name",
                  "bio": "bio",
                  "timezone": "timezone",
                  "language": "language",
                  "profile_public": true,
                  "allow_notifications": true,
                  "avatar_url": "avatar_url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = UserRead(
            id: "id",
            email: "email",
            isActive: Optional(true),
            isSuperuser: Optional(true),
            isVerified: Optional(true),
            username: Optional("username"),
            phone: Optional("phone"),
            firstName: Optional("first_name"),
            lastName: Optional("last_name"),
            bio: Optional("bio"),
            timezone: Optional("timezone"),
            language: Optional("language"),
            profilePublic: Optional(true),
            allowNotifications: Optional(true),
            avatarUrl: Optional("avatar_url")
        )
        let response = try await client.auth.usersCurrentUser()
        try #require(response == expectedResponse)
    }

    @Test func usersPatchCurrentUser1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "id": "id",
                  "email": "email",
                  "is_active": true,
                  "is_superuser": true,
                  "is_verified": true,
                  "username": "username",
                  "phone": "phone",
                  "first_name": "first_name",
                  "last_name": "last_name",
                  "bio": "bio",
                  "timezone": "timezone",
                  "language": "language",
                  "profile_public": true,
                  "allow_notifications": true,
                  "avatar_url": "avatar_url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = UserRead(
            id: "id",
            email: "email",
            isActive: Optional(true),
            isSuperuser: Optional(true),
            isVerified: Optional(true),
            username: Optional("username"),
            phone: Optional("phone"),
            firstName: Optional("first_name"),
            lastName: Optional("last_name"),
            bio: Optional("bio"),
            timezone: Optional("timezone"),
            language: Optional("language"),
            profilePublic: Optional(true),
            allowNotifications: Optional(true),
            avatarUrl: Optional("avatar_url")
        )
        let response = try await client.auth.usersPatchCurrentUser(request: UserUpdate(

        ))
        try #require(response == expectedResponse)
    }

    @Test func usersPatchCurrentUser2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "id": "id",
                  "email": "email",
                  "is_active": true,
                  "is_superuser": true,
                  "is_verified": true,
                  "username": "username",
                  "phone": "phone",
                  "first_name": "first_name",
                  "last_name": "last_name",
                  "bio": "bio",
                  "timezone": "timezone",
                  "language": "language",
                  "profile_public": true,
                  "allow_notifications": true,
                  "avatar_url": "avatar_url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = UserRead(
            id: "id",
            email: "email",
            isActive: Optional(true),
            isSuperuser: Optional(true),
            isVerified: Optional(true),
            username: Optional("username"),
            phone: Optional("phone"),
            firstName: Optional("first_name"),
            lastName: Optional("last_name"),
            bio: Optional("bio"),
            timezone: Optional("timezone"),
            language: Optional("language"),
            profilePublic: Optional(true),
            allowNotifications: Optional(true),
            avatarUrl: Optional("avatar_url")
        )
        let response = try await client.auth.usersPatchCurrentUser(request: UserUpdate(

        ))
        try #require(response == expectedResponse)
    }

    @Test func usersUser1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "id": "id",
                  "email": "email",
                  "is_active": true,
                  "is_superuser": true,
                  "is_verified": true,
                  "username": "username",
                  "phone": "phone",
                  "first_name": "first_name",
                  "last_name": "last_name",
                  "bio": "bio",
                  "timezone": "timezone",
                  "language": "language",
                  "profile_public": true,
                  "allow_notifications": true,
                  "avatar_url": "avatar_url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = UserRead(
            id: "id",
            email: "email",
            isActive: Optional(true),
            isSuperuser: Optional(true),
            isVerified: Optional(true),
            username: Optional("username"),
            phone: Optional("phone"),
            firstName: Optional("first_name"),
            lastName: Optional("last_name"),
            bio: Optional("bio"),
            timezone: Optional("timezone"),
            language: Optional("language"),
            profilePublic: Optional(true),
            allowNotifications: Optional(true),
            avatarUrl: Optional("avatar_url")
        )
        let response = try await client.auth.usersUser(id: "id")
        try #require(response == expectedResponse)
    }

    @Test func usersUser2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "id": "id",
                  "email": "email",
                  "is_active": true,
                  "is_superuser": true,
                  "is_verified": true,
                  "username": "username",
                  "phone": "phone",
                  "first_name": "first_name",
                  "last_name": "last_name",
                  "bio": "bio",
                  "timezone": "timezone",
                  "language": "language",
                  "profile_public": true,
                  "allow_notifications": true,
                  "avatar_url": "avatar_url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = UserRead(
            id: "id",
            email: "email",
            isActive: Optional(true),
            isSuperuser: Optional(true),
            isVerified: Optional(true),
            username: Optional("username"),
            phone: Optional("phone"),
            firstName: Optional("first_name"),
            lastName: Optional("last_name"),
            bio: Optional("bio"),
            timezone: Optional("timezone"),
            language: Optional("language"),
            profilePublic: Optional(true),
            allowNotifications: Optional(true),
            avatarUrl: Optional("avatar_url")
        )
        let response = try await client.auth.usersUser(id: "id")
        try #require(response == expectedResponse)
    }

    @Test func usersPatchUser1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "id": "id",
                  "email": "email",
                  "is_active": true,
                  "is_superuser": true,
                  "is_verified": true,
                  "username": "username",
                  "phone": "phone",
                  "first_name": "first_name",
                  "last_name": "last_name",
                  "bio": "bio",
                  "timezone": "timezone",
                  "language": "language",
                  "profile_public": true,
                  "allow_notifications": true,
                  "avatar_url": "avatar_url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = UserRead(
            id: "id",
            email: "email",
            isActive: Optional(true),
            isSuperuser: Optional(true),
            isVerified: Optional(true),
            username: Optional("username"),
            phone: Optional("phone"),
            firstName: Optional("first_name"),
            lastName: Optional("last_name"),
            bio: Optional("bio"),
            timezone: Optional("timezone"),
            language: Optional("language"),
            profilePublic: Optional(true),
            allowNotifications: Optional(true),
            avatarUrl: Optional("avatar_url")
        )
        let response = try await client.auth.usersPatchUser(
            id: "id",
            request: UserUpdate(

            )
        )
        try #require(response == expectedResponse)
    }

    @Test func usersPatchUser2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "id": "id",
                  "email": "email",
                  "is_active": true,
                  "is_superuser": true,
                  "is_verified": true,
                  "username": "username",
                  "phone": "phone",
                  "first_name": "first_name",
                  "last_name": "last_name",
                  "bio": "bio",
                  "timezone": "timezone",
                  "language": "language",
                  "profile_public": true,
                  "allow_notifications": true,
                  "avatar_url": "avatar_url"
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = UserRead(
            id: "id",
            email: "email",
            isActive: Optional(true),
            isSuperuser: Optional(true),
            isVerified: Optional(true),
            username: Optional("username"),
            phone: Optional("phone"),
            firstName: Optional("first_name"),
            lastName: Optional("last_name"),
            bio: Optional("bio"),
            timezone: Optional("timezone"),
            language: Optional("language"),
            profilePublic: Optional(true),
            allowNotifications: Optional(true),
            avatarUrl: Optional("avatar_url")
        )
        let response = try await client.auth.usersPatchUser(
            id: "id",
            request: UserUpdate(

            )
        )
        try #require(response == expectedResponse)
    }

    @Test func getMyProfile1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "id": "id",
                  "username": "username",
                  "first_name": "first_name",
                  "last_name": "last_name",
                  "avatar_url": "avatar_url",
                  "bio": "bio",
                  "profile_public": true
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = UserProfile(
            id: "id",
            username: Optional("username"),
            firstName: Optional("first_name"),
            lastName: Optional("last_name"),
            avatarUrl: Optional("avatar_url"),
            bio: Optional("bio"),
            profilePublic: Optional(true)
        )
        let response = try await client.auth.getMyProfile()
        try #require(response == expectedResponse)
    }

    @Test func getMyProfile2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "id": "id",
                  "username": "username",
                  "first_name": "first_name",
                  "last_name": "last_name",
                  "avatar_url": "avatar_url",
                  "bio": "bio",
                  "profile_public": true
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = UserProfile(
            id: "id",
            username: Optional("username"),
            firstName: Optional("first_name"),
            lastName: Optional("last_name"),
            avatarUrl: Optional("avatar_url"),
            bio: Optional("bio"),
            profilePublic: Optional(true)
        )
        let response = try await client.auth.getMyProfile()
        try #require(response == expectedResponse)
    }

    @Test func getUserProfile1() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "id": "id",
                  "username": "username",
                  "first_name": "first_name",
                  "last_name": "last_name",
                  "avatar_url": "avatar_url",
                  "bio": "bio",
                  "profile_public": true
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = UserProfile(
            id: "id",
            username: Optional("username"),
            firstName: Optional("first_name"),
            lastName: Optional("last_name"),
            avatarUrl: Optional("avatar_url"),
            bio: Optional("bio"),
            profilePublic: Optional(true)
        )
        let response = try await client.auth.getUserProfile(userId: "user_id")
        try #require(response == expectedResponse)
    }

    @Test func getUserProfile2() async throws -> Void {
        let stub = WireStub()
        stub.setResponse(
            body: Data(
                """
                {
                  "id": "id",
                  "username": "username",
                  "first_name": "first_name",
                  "last_name": "last_name",
                  "avatar_url": "avatar_url",
                  "bio": "bio",
                  "profile_public": true
                }
                """.utf8
            )
        )
        let client = ApiClient(
            baseURL: "https://api.fern.com",
            token: "<token>",
            urlSession: stub.urlSession
        )
        let expectedResponse = UserProfile(
            id: "id",
            username: Optional("username"),
            firstName: Optional("first_name"),
            lastName: Optional("last_name"),
            avatarUrl: Optional("avatar_url"),
            bio: Optional("bio"),
            profilePublic: Optional(true)
        )
        let response = try await client.auth.getUserProfile(userId: "user_id")
        try #require(response == expectedResponse)
    }
}