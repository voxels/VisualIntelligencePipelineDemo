import Foundation

public enum InputTypeEnum: String, Codable, Hashable, CaseIterable, Sendable {
    case tiktok
}